﻿namespace InnoageAdminPortalAPI.Encryption
{
    public interface IEncryption
    {
        string EncryptString(string plainText, string Key);
    }
}
