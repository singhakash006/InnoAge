﻿using SendGrid;
using SendGrid.Helpers.Mail;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace InnoageAdminPortalAPI.Services
{
    public class EmailService:IEmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task SendEmailAsync(string email, string title, string message, List<string>? ccEmails = null)
        {
            var apiKey = _configuration["EmailSettings:SendGridApiKey"];
            var senderEmail = _configuration["EmailSettings:SenderEmail"];
            var senderName = _configuration["EmailSettings:SenderName"];

            var client = new SendGridClient(apiKey);
            var from = new EmailAddress(senderEmail, senderName);
            var to = new EmailAddress(email);

            var msg = MailHelper.CreateSingleEmail(from, to, title, message, message);

            // Add CC recipients if provided
            if (ccEmails != null && ccEmails.Count > 0)
            {
                msg.AddCcs(ccEmails.Select(ccEmail => new EmailAddress(ccEmail)).ToList());
            }

            var response = await client.SendEmailAsync(msg);

            Console.WriteLine($"SendGrid Email Status: {response.StatusCode}");
        }

    }
}
