﻿
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using System.Threading.Tasks;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class RoleService:IRoleService
    {
        private readonly IRoleRepository _roleRepository;
        private readonly ILogger _logger;

        public RoleService(IRoleRepository roleRepository, ILogHelper logHelper)
        {
            _roleRepository = roleRepository;
            _logger = logHelper.GetLogger<RoleService>();
        }

        public async Task<Role?> GetRoleByIdAsync(LoggingProperties loggingProperties, string roleId)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching role details for RoleId: {RoleId}", roleId);

            try
            {
                var role = await _roleRepository.GetByIdAsync(loggingProperties, roleId);

                if (role == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No role found for RoleId: {RoleId}", roleId);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully fetched role details for RoleId: {RoleId}", roleId);
                }

                return role;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching role details for RoleId: {RoleId}", roleId);
                throw;
            }
        }

    }
}
