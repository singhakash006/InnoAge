﻿using InnoageAdminPortalAPI.Repository;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Entity;
using System.Security.Claims;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Models;
using System.Diagnostics;
using ILogger = Serilog.ILogger;
using InnoageAdminPortalAPI.Helpers;
using Microsoft.AspNetCore.JsonPatch;
using MongoDB.Driver;

namespace InnoageAdminPortalAPI.Services
{
    public class UserService:IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger _logger;

        public UserService(IUserRepository userRepository, IHttpContextAccessor httpContextAccessor, IRoleRepository roleRepository, ILogHelper logHelper)
        {
            _userRepository = userRepository;
            _httpContextAccessor = httpContextAccessor;
            _roleRepository = roleRepository;
            _logger = logHelper.GetLogger<UserService>();
        }

       

        public async Task<List<User>> GetEmployeeByTeamIdAsync(LoggingProperties loggingProperties)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.GetEmployeeByTeamIdAsync));

                // Extracting userId from the HTTP context
                string userId = _httpContextAccessor.HttpContext?.User?.FindFirst("userId")?.Value;
                if (string.IsNullOrEmpty(userId))
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No userId found in HTTP context.");
                    return new List<User>(); // Return empty list to avoid null reference issues.
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug("Fetched userId from claims: {UserId}", userId);

                // Fetch email using userId
                string? user_email = await _userRepository.GetEmailByIdAsync(loggingProperties, userId);
                if (string.IsNullOrEmpty(user_email))
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No user email found for userId: {UserId}", userId);
                    return new List<User>(); // Return empty list to avoid null reference issues.
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug("Fetched email from userId: {UserId}, Email: {Email}", userId, user_email);

                // Get user details
                var user = await _userRepository.GetByEmailAsync(loggingProperties, user_email);
                if (user == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No user found with email: {Email}", user_email);
                    return new List<User>();
                }

                // Fetch Role ID
                var role_id = await _roleRepository.GetIdByRoleAsync(loggingProperties, "Employee");

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug("Fetching employees with Team ID: {TeamId} and Role ID: {RoleId}", user.TeamId, role_id);

                // Fetch employees
                List<User> employees = await _userRepository.GetEmployeeByTeamId(loggingProperties, user.TeamId, role_id);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.User, employees);

                return employees;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.GetEmployeeByTeamIdAsync), ex.Message);

                return new List<User>(); // Return an empty list to prevent runtime exceptions.
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.GetEmployeeByTeamIdAsync), watch.Elapsed.TotalSeconds);
            }
        }




        public async Task<List<User>> GetTLsAsync(LoggingProperties loggingProperties)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.GetTLsAsync));

                var response = await _userRepository.GetTLs(loggingProperties);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.User, response);

                return response;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.GetTLsAsync), ex.Message);

                return new List<User>(); // Return empty list to avoid exceptions.
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.GetTLsAsync), watch.Elapsed.TotalSeconds);
            }
        }




        public async Task<bool?> UpdateUserAsync(LoggingProperties loggingProperties, string EmpId, JsonPatchDocument<User> patchDoc)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodStart, nameof(UpdateUserAsync));

                var existingUser = await _userRepository.GetByEmpIdAsync(EmpId);
                if (existingUser == null)
                    return null;

                patchDoc.ApplyTo(existingUser);
                var filter = Builders<User>.Filter.Eq(u => u.EmployeeId, EmpId);
                var updateDefinition = CreateUpdateDefinition(existingUser);
                return await _userRepository.UpdateUserProfileAsync(filter, updateDefinition);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(UpdateUserAsync), ex.Message);
                throw;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(UpdateUserAsync), watch.Elapsed.TotalSeconds);
            }
        }

        private UpdateDefinition<User> CreateUpdateDefinition(User updatedUser)
        {
            return Builders<User>.Update
                .Set(u => u.Name, updatedUser.Name)
                .Set(u => u.Email, updatedUser.Email)
                .Set(u => u.PhoneNo, updatedUser.PhoneNo)
                .Set(u => u.Image, updatedUser.Image)
                .Set(u => u.Address, updatedUser.Address);
        }







    }
}
