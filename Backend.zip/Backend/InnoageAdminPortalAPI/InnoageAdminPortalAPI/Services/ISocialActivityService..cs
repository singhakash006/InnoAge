﻿using InnoageAdminPortalAPI.Entity;
using Microsoft.IdentityModel.Logging;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;

namespace InnoageAdminPortalAPI.Services
{
    public interface ISocialActivityService
    {
        Task<string> AddActivityAsync(LoggingProperties loggingProperties, AddActivityDto activity);
        Task<PaginatedResponse<ActivityCalendar>> GetActivitiesByCategoryAsync(LoggingProperties loggingProperties, string category, int pageNumber, int pageSize);
    }
}
