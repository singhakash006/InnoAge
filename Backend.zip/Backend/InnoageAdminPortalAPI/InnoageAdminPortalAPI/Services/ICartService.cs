﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface ICartService
    {
        Task<Cart> CreateNewCart(LoggingProperties loggingProperties);
    }
}
