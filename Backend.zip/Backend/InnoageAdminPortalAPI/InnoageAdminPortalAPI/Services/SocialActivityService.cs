using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using System.Diagnostics;
using ILogger = Serilog.ILogger;
using MongoDB.Driver;
using AutoMapper;





namespace InnoageAdminPortalAPI.Services
{
    public class SocialActivityService : ISocialActivityService
    {

        private readonly ISocialActivityRepository _socialActivityRepository;

        private readonly ILogger _logger;
           private readonly IMapper _mapper;

        public SocialActivityService(ISocialActivityRepository socialActivityRepository, ILogHelper logHelper,IMapper mapper)
        {

            _socialActivityRepository = socialActivityRepository;

            _logger = logHelper.GetLogger<SocialActivityService>();
            _mapper = mapper;


        }
        public async Task<string> AddActivityAsync(LoggingProperties loggingProperties, AddActivityDto activityDto)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(AddActivityAsync));


              var activityEntity = _mapper.Map<ActivityCalendar>(activityDto);

                await _socialActivityRepository.AddActivityAsync(activityEntity, loggingProperties);

                return "Activity Added Successfully";
            }
            catch (MongoException ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, "MongoDB Error: {ErrorMessage}", ex.Message);

                return "Database error occurred while adding the activity.";
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, "Error in {MethodName}: {ErrorMessage}", nameof(AddActivityAsync), ex.Message);

                return "An unexpected error occurred while adding the activity.";
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(AddActivityAsync), watch.Elapsed.TotalSeconds);
            }
        }




        public async Task<PaginatedResponse<ActivityCalendar>> GetActivitiesByCategoryAsync(LoggingProperties loggingProperties, string category, int pageNumber, int pageSize)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(GetActivitiesByCategoryAsync));

                var paginatedActivities = await _socialActivityRepository.GetActivitiesByCategoryAsync(loggingProperties, category, pageNumber, pageSize);

                return paginatedActivities;
            }
            catch (MongoException ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, "MongoDB Error: {ErrorMessage}", ex.Message);

                throw new Exception("Database error occurred while fetching activities.", ex);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, "Error in {MethodName}: {ErrorMessage}", nameof(GetActivitiesByCategoryAsync), ex.Message);

                throw new Exception("An unexpected error occurred while fetching activities.", ex);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(GetActivitiesByCategoryAsync), watch.Elapsed.TotalSeconds);
            }
        }





    }
}
