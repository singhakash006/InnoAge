﻿using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface ICommentService
    {
        Task<string> InsertCommentService(LoggingProperties loggingProperties, CommentDto comment);
    }
}
