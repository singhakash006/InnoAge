﻿using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface ILikeService
    {
        Task<string> InsertLike(LoggingProperties loggingProperties, LikeDto like);
    }
}
