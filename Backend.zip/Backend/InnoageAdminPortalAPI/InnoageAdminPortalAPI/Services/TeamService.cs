﻿using InnoageAdminPortalAPI.Constants;
using System.Diagnostics;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using InnoageAdminPortalAPI.Helpers;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class TeamService:ITeamService
    {
        private readonly ITeamRepository _teamRepository;
        private readonly IUserRepository _userRepository;
        private readonly ILogger _logger;

        public TeamService(ITeamRepository teamRepository, IUserRepository userRepository, ILogHelper logHelper)
        {
            _teamRepository = teamRepository;
            _userRepository = userRepository;
            _logger = logHelper.GetLogger<TeamService>();
        }

        

        public async Task<List<object>> GetAllTeamsWithLeaderDetailsAsync(LoggingProperties loggingProperties)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.GetAllTeamsWithLeaderDetailsAsync));

                var teams = await _teamRepository.GetAllAsync(loggingProperties);
                var teamsWithLeaders = new List<object>();

                foreach (var team in teams)
                {
                    User? teamLeader = await _userRepository.GetByIdAsync(loggingProperties, team.TeamLeader);

                    teamsWithLeaders.Add(new
                    {
                        Id = team.Id,
                        TeamName = team.TeamName,
                        TeamLeader = teamLeader != null ? new
                        {
                            Id = teamLeader.Id,
                            Name = teamLeader.Name,
                            Email = teamLeader.Email,
                            Designation = teamLeader.Designation
                        } : null
                    });
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.Teams, teamsWithLeaders);

                return teamsWithLeaders;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.GetAllTeamsWithLeaderDetailsAsync), ex.Message);

                return new List<object>(); // Return an empty list instead of null to prevent errors.
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.GetAllTeamsWithLeaderDetailsAsync), watch.Elapsed.TotalSeconds);
            }
        }


        

        public async Task<string> GetTeamLeaderIdByTeamIdAsync(LoggingProperties loggingProperties, string id)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.GetTeamLeaderIdByTeamIdAsync), new { TeamId = id });

                var teamLeaderId = await _teamRepository.GetTeamLeaderIdByTeamIdAsync(loggingProperties,  id);

                if (string.IsNullOrEmpty(teamLeaderId))
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No Team Leader found for TeamId: {TeamId}", id);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Team Leader ID fetched successfully for TeamId: {TeamId}, LeaderId: {LeaderId}", id, teamLeaderId);
                }

                return teamLeaderId;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.GetTeamLeaderIdByTeamIdAsync), ex.Message);

                return string.Empty; // Return empty string to avoid null reference issues
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.GetTeamLeaderIdByTeamIdAsync), watch.Elapsed.TotalSeconds);
            }
        }


        
    }
}
