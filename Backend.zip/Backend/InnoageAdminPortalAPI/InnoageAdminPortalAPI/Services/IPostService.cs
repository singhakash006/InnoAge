﻿using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface IPostService
    {
        Task<List<DashboardDto>> GetAllLatestPostService(LoggingProperties loggingProperties, DateTime? lastFetchedDate, int limit = 10);
        Task<string> InsertPostService(LoggingProperties loggingProperties, PostDto post);
        Task<string> UpdatePollPostService(LoggingProperties loggingProperties, PollDto poll);
    }
}
