﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using System.Diagnostics;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class CommentService:ICommentService
    {
        private readonly ICommentRepository _commentRepository;
        private readonly ILogger _logger;
        public CommentService(ICommentRepository commentRepository, ILogHelper logHelper)
        {
            _commentRepository = commentRepository;
            _logger = logHelper.GetLogger<PostRepository>();
        }

        public async Task<string> InsertCommentService(LoggingProperties loggingProperties, CommentDto comment)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(InsertCommentService));
                if (comment != null)
                {
                    var commentDatas= await _commentRepository.InsertComment(loggingProperties, comment);

                    return "Comment Inserted Success Full";
                }
                return "Comment  is empty";
            }
            catch (Exception ex) {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                          .Error(ex, LogMessages.ErrorOccured, nameof(InsertCommentService), ex.Message);

                throw ex;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(InsertCommentService), watch.Elapsed.TotalSeconds);
            }
        }
    }
}
