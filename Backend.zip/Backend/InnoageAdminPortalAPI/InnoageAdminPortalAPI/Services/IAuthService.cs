﻿using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Entity;

namespace InnoageAdminPortalAPI.Services
{
    public interface IAuthService
    {
        Task<UserResponseDto> LoginAsync(LoggingProperties loggingProperties, LoginDto model);
        Task<string> SignupAsync(LoggingProperties loggingProperties, User user);
        Task<bool> RequestPasswordResetAsync(LoggingProperties loggingProperties, string email);
        Task<bool> ResetPasswordAsync(LoggingProperties loggingProperties, string token, string newPassword);
    }
}
