﻿using InnoageAdminPortalAPI.Authorization;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Encryption;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Repository;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Threading.Tasks;
using static InnoageAdminPortalAPI.Constants.Constants;
using InnoageAdminPortalAPI.Enums;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;

        private readonly ITeamService _teamService;
        private readonly ICartService _cartService;
        private readonly IDepartmentService _departmentService;
        private readonly IPasswordResetRepository _passwordResetRepository;
        private readonly IEmailService _emailService;
        private readonly ILogger _logger;
        private readonly IEncryption _encryption;
        private readonly IConfiguration _configuration;
        private readonly IJwtUtils _jwtUtils;
        private readonly IRefreshTokenRepository _refreshTokenRepository;
        private readonly IRoleService _roleService;

        public AuthService(IRoleService roleService, IUserRepository userRepository, ITeamService teamService, ICartService cartService, IDepartmentService departmentService, IPasswordResetRepository passwordResetRepository, IEmailService emailService, ILogHelper logHelper, IEncryption encryption, IConfiguration configuration, IJwtUtils jwtUtils, IRefreshTokenRepository refreshTokenRepository)
        {
            _userRepository = userRepository;
            _teamService = teamService;
            _cartService = cartService;
            _departmentService = departmentService;
            _passwordResetRepository = passwordResetRepository;
            _emailService = emailService;
            _logger = logHelper.GetLogger<AuthService>();
            _encryption = encryption;
            _configuration = configuration;
            _jwtUtils = jwtUtils;
            _refreshTokenRepository = refreshTokenRepository;
            _roleService = roleService;
        }

        public async Task<UserResponseDto> LoginAsync(LoggingProperties loggingProperties, LoginDto model)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.MethodStart, nameof(LoginAsync));
                return await GetAuthUserAsync(loggingProperties, model);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .ForContext(LogProperties.UserId, loggingProperties.UserId)
                          .Error(ex, LogMessages.ErrorOccured, nameof(LoginAsync), ex.Message);

                throw ex;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.MethodEnd, nameof(LoginAsync), watch.Elapsed.TotalSeconds);
            }
        }


        public async Task<string> SignupAsync(LoggingProperties loggingProperties, User user)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Information(LogMessages.MethodStart, nameof(this.SignupAsync));

                var existingUser = await _userRepository.GetByEmailAsync(loggingProperties, user.Email);
                if (existingUser != null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                           .Warning(LogMessages.UserExists, user.Email, existingUser.Id);

                    return "You are already registered. Please login using your credentials.";
                }

                var newCart = await _cartService.CreateNewCart(loggingProperties);
                var TeamLeaderId = await _teamService.GetTeamLeaderIdByTeamIdAsync(loggingProperties, user.TeamId);

                var key = _configuration[Hashing.Key];
                user.Password = _encryption.EncryptString(user.Password, key);
                user.CartId = newCart.Id;
                user.TeamLeaderId = TeamLeaderId;

                await _userRepository.AddAsync(loggingProperties, user);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Information(LogMessages.AddSuccess, user.Id, Constants.Constants.Collections.User);

                return "User registered successfully.";
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorResponse, nameof(this.SignupAsync), ex.Message);

                return "An error occurred while processing your request. Please try again later.";
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(this.SignupAsync), watch.Elapsed.TotalSeconds);
            }
        }



        public async Task<bool> RequestPasswordResetAsync(LoggingProperties loggingProperties, string email)
        {
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.RequestPasswordResetAsync));

                var user = await _userRepository.GetByEmailAsync(loggingProperties, email);
                if (user == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Password reset requested but user not found: {Email}", email);
                    return false;
                }

                var token = RandomNumberGenerator.GetInt32(100000, 999999).ToString();
                var expiry = DateTime.UtcNow.AddHours(1); // Token valid for 1 hour

                await _passwordResetRepository.DeleteResetTokenByEmailAsync(loggingProperties, email);
                await _passwordResetRepository.SaveResetTokenAsync(loggingProperties, email, token, expiry);

                string subject = "Password Reset Request";
                string body = $"<p>Token to reset your password is: <strong>{token}</strong></p>";

                await _emailService.SendEmailAsync(email, subject, body);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Password reset token generated and sent for: {Email}", email);

                return true;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.RequestPasswordResetAsync), ex.Message);

                return false; // Fail silently to avoid exposing internal errors
            }
            finally
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.RequestPasswordResetAsync));
            }
        }


        public async Task<bool> ResetPasswordAsync(LoggingProperties loggingProperties, string token, string newPassword)
        {
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.ResetPasswordAsync));

                var resetToken = await _passwordResetRepository.GetValidResetTokenAsync(loggingProperties, token);
                if (resetToken == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Invalid or expired password reset token: {Token}", token);
                    return false; // Invalid or expired token
                }

                var key = _configuration[Hashing.Key];
                string hashedPassword = _encryption.EncryptString(newPassword, key);

                await _userRepository.UpdatePasswordAsync(loggingProperties, resetToken.Email, hashedPassword);

                // Delete token after use
                await _passwordResetRepository.DeleteResetTokenAsync(loggingProperties, token);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Password successfully updated for user: {Email}", resetToken.Email);

                return true;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.ResetPasswordAsync), ex.Message);
                return false;
            }
            finally
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.ResetPasswordAsync));
            }
        }


        #region private methods
        private async Task<UserResponseDto> GetAuthUserAsync(LoggingProperties loggingProperties, LoginDto model)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.MethodStart, nameof(GetAuthUserAsync));

                User user = await _userRepository.GetByEmailAsync(loggingProperties, model.Email);
                var departmemt = await _departmentService.GetDepartmentByIdAsync(loggingProperties, user.DepartmentId);
                var _role = await _roleService.GetRoleByIdAsync(loggingProperties, user.RoleId);
                Roles userRole = Enum.Parse<Roles>(_role.RoleName);

                if (user != null)
                {
                    if (user.isLocked)
                    {
                        _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                               .Error(AppMessages.AccountLocked);

                        throw new Exception(AppMessages.AccountLocked);
                    }
                    else if (user.isActive)
                    {
                        if (user.Password == _encryption.EncryptString(
                            model.Password, _configuration[Constants.Constants.Hashing.Key]))
                        {

                            var userDetails = new UserResponseDto
                            {
                                User = new UserDetailResponseDto
                                {
                                    Id = user.Id,
                                    Name = user.Name,
                                    Designation = user.Designation,
                                    Department = departmemt.DepartmentName,
                                    PhoneNo = user.PhoneNo,
                                    Address = user.Address,
                                    DOB = user.DOB,
                                    DOJ = user.DOJ,
                                    Image = user.Image,
                                    UserRole = userRole,
                                    Email = user.Email,
                                    EmployeeId = user.EmployeeId,
                                }
                            };
                            var token = _jwtUtils.GenerateJwtToken(userDetails.User);
                            userDetails.Token = token.Token;
                            userDetails.TokenExpiration = token.ValidTo;
                            var refreshToken = _jwtUtils.GenerateRefreshToken();
                            refreshToken.UserId = user.Id;
                            await _refreshTokenRepository.AssociateRefreshTokenAsync(loggingProperties, refreshToken);
                            userDetails.RefreshToken = refreshToken.Token;

                            await RemoveOldRefreshTokensAsync(loggingProperties, user.Id);
                            return userDetails;
                        }
                        else
                        {
                            throw new Exception(AppMessages.InvalidCredentials);
                        }
                    }
                    else
                    {
                        throw new Exception(AppMessages.AccountDeactivated);
                    }
                }
                else
                {
                    throw new Exception(AppMessages.InvalidCredentials);
                }
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                   .Error(ex, LogMessages.ErrorOccured, nameof(GetAuthUserAsync), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                      .Debug(LogMessages.MethodEnd, nameof(GetAuthUserAsync), watch.Elapsed.TotalSeconds);
            }

        }

        private async Task RemoveOldRefreshTokensAsync(LoggingProperties loggingProperties, string userId)
        {
            await _refreshTokenRepository.DeleteOldRefreshTokenAsync(
                loggingProperties,
                userId,
                Convert.ToInt32(_configuration[Constants.Constants.JWT.RefreshTokenTTL]));
        }

        #endregion

    }
}