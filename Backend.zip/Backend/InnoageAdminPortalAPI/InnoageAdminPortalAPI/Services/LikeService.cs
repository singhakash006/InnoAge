﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using System.Diagnostics;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class LikeService:ILikeService
    {
        private readonly ILikeRepository _likeRepository;
        private readonly ILogger _logger;
        public LikeService(ILikeRepository likeRepository, ILogHelper logHelper) {
        
            _likeRepository = likeRepository;
            _logger = logHelper.GetLogger<PostRepository>();
        }
        public async Task<string> InsertLike(LoggingProperties loggingProperties, LikeDto like)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(InsertLike));
                
                    await _likeRepository.InsertLike(loggingProperties, like);
                return "Like Update Successfull";
                
            }
            catch (Exception ex) {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                             .Error(ex, LogMessages.ErrorOccured, nameof(InsertLike), ex.Message);

                throw ex;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(InsertLike), watch.Elapsed.TotalSeconds);
            }

        }

    }
}
