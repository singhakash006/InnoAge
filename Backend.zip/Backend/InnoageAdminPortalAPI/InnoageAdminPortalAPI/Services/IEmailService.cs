﻿namespace InnoageAdminPortalAPI.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(string email, string title, string message, List<string>? ccEmails = null);
    }
}
