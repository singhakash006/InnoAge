﻿using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface INominateShoutOutService
    {
        Task<object> NominateShoutEmployee(LoggingProperties loggingProperties, string userId, string teamId, string Reason, string Nomination_Type, string[] ManagerIds);
        Task<List<object>> GetNominationsByTeamLeaders(LoggingProperties loggingProperties);
    }
}
