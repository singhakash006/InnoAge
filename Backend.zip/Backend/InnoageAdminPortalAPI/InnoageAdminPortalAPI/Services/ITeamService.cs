﻿using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface ITeamService
    {
        Task<List<object>> GetAllTeamsWithLeaderDetailsAsync(LoggingProperties loggingProperties);
        Task<string> GetTeamLeaderIdByTeamIdAsync(LoggingProperties loggingProperties, string id);
    }
}
