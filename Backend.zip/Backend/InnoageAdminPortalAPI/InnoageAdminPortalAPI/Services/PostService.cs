﻿using AutoMapper;
using Humanizer;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using System.Diagnostics;
using System.Threading.Tasks;
using ILogger = Serilog.ILogger;
namespace InnoageAdminPortalAPI.Services
{
    public class PostService:IPostService
    {
        private readonly IPostRepository _postRepository;
        private readonly ILogger _logger;
        private readonly IUserRepository _userRepository;
        private readonly INominationRepository _nominationRepository;
        private readonly ICloudinaryService _cloudinaryService;
        private readonly IMapper _mapper;
        public PostService(IPostRepository postRepository, IUserRepository userRepository, INominationRepository nominationRepository, ILogHelper logHelper, ICloudinaryService cloudinaryService, IMapper mapper)
        {
            _postRepository = postRepository;
            _userRepository = userRepository;
            _nominationRepository = nominationRepository;
            _cloudinaryService = cloudinaryService;
            _logger = logHelper.GetLogger<PostService>();
            _mapper = mapper;
        }


        public async Task<List<DashboardDto>> GetAllLatestPostService(LoggingProperties loggingProperties, DateTime? lastFetchedDate, int limit = 10)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
               .Debug(LogMessages.MethodStart, nameof(GetAllLatestPostService));

                var posts = await _postRepository.GetAllPost(loggingProperties,lastFetchedDate, limit);

                var nominationPost = await _nominationRepository.GetAllNominationsByLatestTime(loggingProperties,lastFetchedDate, limit);

                var postTask = posts.Concat(nominationPost).Select(async item =>
                {
                    var postUser = (item.PostData != null) ? await _userRepository.GetByIdAsync(loggingProperties, item.PostData?.userId) : null;
                    item.UserData = (postUser != null)?(new UserDetailed { UserName = postUser?.Name, ProfileImage = postUser?.Image }) : null;

                    return item;
                }).ToList();

                var postList = await Task.WhenAll(postTask);



              return postList.OrderByDescending(x => x.NominationData?.VerifiedAt ?? x.PostData?.created_at).Take(limit).ToList();
              
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorOccured, nameof(GetAllLatestPostService), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(GetAllLatestPostService), watch.Elapsed.TotalSeconds);
            }


        }

        public async Task<string> InsertPostService(LoggingProperties loggingProperties, PostDto post)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(InsertPostService));

                string imageUrl = "";
                if(post.image !=null && post.image.Length > 0)
                {
                    using var stream = post.image.OpenReadStream();
                    imageUrl = await _cloudinaryService.UploadImageAsync( loggingProperties,stream, "PostImage");
                }

                var userPost = _mapper.Map<Posts>(post);
                userPost.image = imageUrl;
                return await _postRepository.InsertPost(loggingProperties, userPost);

            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
            .Error(ex, LogMessages.ErrorOccured, nameof(InsertPostService), ex.Message);

                throw ex;
            }
            finally
            {
                watch.Stop();

                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(InsertPostService), watch.Elapsed.TotalSeconds);
            }

        }

        public async Task<string> UpdatePollPostService(LoggingProperties loggingProperties, PollDto poll)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(UpdatePollPostService));

               return  await _postRepository.UpdatePoll(loggingProperties, poll);
               
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                         .Error(ex, LogMessages.ErrorOccured, nameof(UpdatePollPostService), ex.Message);

                throw ex;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(UpdatePollPostService), watch.Elapsed.TotalSeconds);
            }

        }
    }
}
