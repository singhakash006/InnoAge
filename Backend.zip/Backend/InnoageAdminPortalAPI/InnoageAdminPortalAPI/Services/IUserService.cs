﻿using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Entity;
using Microsoft.AspNetCore.JsonPatch;

namespace InnoageAdminPortalAPI.Services
{
    public interface IUserService
    {
        Task<List<User>> GetEmployeeByTeamIdAsync(LoggingProperties loggingProperties);
        Task<List<User>> GetTLsAsync(LoggingProperties loggingProperties);
        Task<bool?> UpdateUserAsync(LoggingProperties loggingProperties, string EmpId, JsonPatchDocument<User> patchDoc);
    }
}
