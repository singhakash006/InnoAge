﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class DepartmentService:IDepartmentService
    {
        private readonly IDepartmentRepository _departmentRepository;
        private readonly ILogger _logger;

        public DepartmentService(IDepartmentRepository departmentRepository, ILogHelper logHelper)
        {
            _departmentRepository = departmentRepository;
            _logger = logHelper.GetLogger<DepartmentService>();
        }

      
        public async Task<Department?> GetDepartmentByIdAsync(LoggingProperties loggingProperties, string departmentId)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching department details for DepartmentId: {DepartmentId}", departmentId);

            try
            {
                var department = await _departmentRepository.GetDepartmentByIdAsync(loggingProperties, departmentId);

                if (department == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Department not found for DepartmentId: {DepartmentId}", departmentId);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully retrieved department details for DepartmentId: {DepartmentId}", departmentId);
                }

                return department;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching department details for DepartmentId: {DepartmentId}", departmentId);

                throw;
            }
        }



       
    }
}
