﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class CartService:ICartService
    {
        private readonly ICartRepository _cartRepository;
        private readonly ILogger _logger;

        public CartService(ICartRepository cartRepository, ILogHelper logHelper)
        {
            _cartRepository = cartRepository;
            _logger = logHelper.GetLogger<CartService>();
        }


      

        public async Task<Cart> CreateNewCart(LoggingProperties loggingProperties)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Creating a new cart.");

            try
            {
                var cart = await _cartRepository.CreateCartAsync(loggingProperties);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("New cart created successfully. CartId: {CartId}", cart.Id);

                return cart;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while creating a new cart.");

                throw;
            }
        }



    }
}
