﻿using System.Diagnostics;
using System.Security.Claims;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using InnoageAdminPortalAPI.Enums;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Services
{
    public class NominateShoutOutService:INominateShoutOutService
    {
        private readonly INominationRepository _nominationRepository;
        private readonly ITeamRepository _teamRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly ICartRepository _cartRepository;
        private readonly IEmailService _emailService;
        private readonly IUserRepository _userRepository;
        //private readonly RoleRepository _roleRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger _logger;


        public NominateShoutOutService(INominationRepository nominationRepository, IEmailService emailService, IUserRepository userRepository, ILogHelper logHelper, IHttpContextAccessor httpContextAccessor, ICartRepository cartRepository , IRoleRepository roleRepository, ITeamRepository teamRepository)
        {
            _nominationRepository = nominationRepository;
            _emailService = emailService;
            _userRepository = userRepository;
            _httpContextAccessor = httpContextAccessor;
            //_roleRepository = roleRepository;
            _cartRepository = cartRepository;
            _roleRepository = roleRepository;
            _teamRepository = teamRepository;
            _logger = logHelper.GetLogger<NominateShoutOutService>();
        }


        public async Task<object> NominateShoutEmployee(LoggingProperties loggingProperties, string userId, string teamId, string Reason, string Nomination_Type, string[] ManagerIds)
        {

            try
            {
                string nominator_userId = _httpContextAccessor.HttpContext?.User?.FindFirst("userId")?.Value;
                string? nominatorEmail = await _userRepository.GetEmailByIdAsync(loggingProperties, nominator_userId);
                if (string.IsNullOrEmpty(nominatorEmail))
                {
                    return new { success = false, message = "Invalid nominator email." };
                }

                User? nominator = await _userRepository.GetByEmailAsync(loggingProperties, nominatorEmail);
                if (nominator == null)
                {
                    return new { success = false, message = "Nominator not found in the system." };
                }

                User? nominee = null;

                if (userId != null)
                {
                    nominee = await _userRepository.GetByIdAsync(loggingProperties, userId);
                }
                else
                {
                    var _team = await _teamRepository.GetByIdAsync(loggingProperties, teamId);

                    if (_team?.TeamLeader != null)  
                    {
                        nominee = await _userRepository.GetByIdAsync(loggingProperties, _team.TeamLeader);
                    }
                }

                if (nominee == null)
                {
                    return new { success = false, message = "Nominee not found in the system." };
                }

                var nominatorRole = await _roleRepository.GetByIdAsync(loggingProperties, nominator.RoleId);
                Roles nominator_rollName = Enum.Parse<Roles>(nominatorRole.RoleName);

                int currentDay = DateTime.UtcNow.Day;
                if (nominator_rollName == Roles.TeamLeader && currentDay > 25 && Nomination_Type == "Star of the month" )
                {
                    return new { success = false, message = "Nominations by TeamLeader are only allowed from the 1st to the 20th of each month." };
                }
                //if (nominatorRole.RoleName == "HR" && currentDay <= 20 && currentDay > 25)
                //{
                //    return new { success = false, message = "Nominations by HR are only allowed from the 20 to the 25th of each month." };
                //}

                if (nominator_rollName == Roles.HR && Nomination_Type == "Star of the month")
                {
                    var response = await _nominationRepository.SelectFromNominatedEmployeesAsync(loggingProperties, Nomination_Type, userId);
                    if (response)
                    {                                         
                        User? teamLeader = await _userRepository.GetByIdAsync(loggingProperties, nominee.TeamLeaderId);
                        await _emailService.SendEmailAsync(nominee.Email, "Congratulations, Star Of The Month", $"Employee {nominee.Name} was nominated by HR {nominator.Name}", [nominatorEmail, teamLeader.Email]);
                        return new { success = true, message = "Star of the month selected" };
                    }
                    return new { success = false, message = "Failed to select star of month.." };
                }


                if (Nomination_Type != "Shoutout" && nominator_rollName == Roles.Employee)
                {
                    return new { success = false, message = "Only Team Leaders/HR can nominate employees for this role." };
                }

                if (nominator_rollName == Roles.TeamLeader && nominator.TeamId != nominee.TeamId)
                {
                    return new { success = false, message = "You can submit a shoutout/Nomination for your team members only." };
                }

                if (Nomination_Type == "Shoutout")
                {
                    var nominatorXP = await _cartRepository.GetXPAsync(loggingProperties, nominator.CartId);
                    if(nominatorXP <= 0)
                    {
                        return new { success = false, message = "You have already used all your shoutouts for this quarter." };
                    }

                    await _cartRepository.DecrementXPAsync(loggingProperties, nominator.CartId);
                    Nomination nomination = new Nomination { UserId = userId, Nomination_Type = Nomination_Type, Reason = Reason, Nominated_By = nominator.Id, TeamId = teamId, isApproved = true, VerifiedAt = DateTime.UtcNow };
                    await _nominationRepository.AddNominationAsync(nomination);
                    
                }
                else
                {
                    List<Nomination> nominations = await _nominationRepository.GetNominationsByTypeAsync(loggingProperties, Nomination_Type);

                    if(Nomination_Type == "Star of the month")
                    {
                        var existingTeamIds = await Task.WhenAll(nominations.Select(it => _userRepository.GetTeamByIdAsync(loggingProperties, it.UserId)));

                        if (existingTeamIds.Contains(nominee.TeamId))
                        {
                            return new { success = false, message = "Another member from this team has already been nominated for this role." };
                        }
                    }
                    else
                    {
                        if(nominations.Count != 0)
                        {
                            return new { success = false, message = "Another One is already been nominated for this role." };
                        }
                    }
                       
                    if(teamId == null)
                    {
                        if(Nomination_Type == "Star of the month")
                        {
                            Nomination nomination = new Nomination { UserId = userId, Nomination_Type = Nomination_Type, Reason = Reason, Nominated_By = nominator.Id, TeamId = teamId, isApproved = false };
                            await _nominationRepository.AddNominationAsync(nomination);
                        }
                        else
                        {
                            Nomination nomination = new Nomination { UserId = userId, Nomination_Type = Nomination_Type, Reason = Reason, Nominated_By = nominator.Id, TeamId = teamId, isApproved = true, VerifiedAt=DateTime.UtcNow };
                            await _nominationRepository.AddNominationAsync(nomination);
                        }
                    }
                    else
                    {
                        Nomination nomination = new Nomination { UserId = userId, Nomination_Type = Nomination_Type, Reason = Reason, Nominated_By = nominator.Id, TeamId = teamId, isApproved = true, VerifiedAt = DateTime.UtcNow };
                        await _nominationRepository.AddNominationAsync(nomination);
                    }

                       
                    
                }

                List<string> managerEmails = new List<string>();

                foreach (var managerId in ManagerIds)
                {
                    string? email = await _userRepository.GetEmailByIdAsync(loggingProperties, managerId);
                    if (!string.IsNullOrEmpty(email))
                    {
                        managerEmails.Add(email);
                    }
                }
                
                if(Nomination_Type != "Shoutout")
                {
                    //adding hr email into list...
                    managerEmails.Add("maniishh2@gmail.com");
                }

                // Send email notifications
                await _emailService.SendEmailAsync(nominee.Email, "New Nomination", $"Employee {nominee.Name} was nominated by Team Leader {nominator.Name}. Reason: {Reason}", managerEmails);

                return new { success = true, message = "Nomination/ShoutOut submitted successfully." };

            }
            catch(Exception err)
            {
                return new { success = false, message = "An unexpected error occurred while processing...." };
            }
        }


        public async Task<List<object>> GetNominationsByTeamLeaders(LoggingProperties loggingProperties)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.GetNominationsByTeamLeaders));

                var nominations = await _nominationRepository.GetNominationsAsync(loggingProperties,  "Star of the month");

                var nominationWithUsers = new List<object>();

                foreach (var nomination in nominations)
                {
                    var user = await _userRepository.GetByIdAsync(loggingProperties, nomination.UserId);

                    nominationWithUsers.Add(new
                    {
                        Id = nomination.Id,
                        UserId = nomination.UserId,
                        User = user, // Fetch user details here
                        Nomination_Type = nomination.Nomination_Type,
                        Nominated_By = nomination.Nominated_By,
                        Reason = nomination.Reason,
                        isApproved = nomination.isApproved,
                        CreatedAt = nomination.CreatedAt,
                        VerifiedAt = nomination.VerifiedAt
                    });
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.Nominations, nominationWithUsers);

                return nominationWithUsers;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.GetNominationsByTeamLeaders), ex.Message);

                return new List<object>(); // Return empty list instead of null to avoid null reference errors.
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.GetNominationsByTeamLeaders), watch.Elapsed.TotalSeconds);
            }
        }


       

    }
}
