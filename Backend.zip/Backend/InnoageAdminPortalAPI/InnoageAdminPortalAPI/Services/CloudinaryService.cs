﻿using CloudinaryDotNet.Actions;
using CloudinaryDotNet;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Threading.Tasks;
using ILogger = Serilog.ILogger;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using System.Diagnostics;
using InnoageAdminPortalAPI.Constants;

namespace InnoageAdminPortalAPI.Services
{
    public class CloudinaryService:ICloudinaryService
    {
        private readonly Cloudinary _cloudinary;
        private readonly ILogger _logger;

        public CloudinaryService(IConfiguration configuration, ILogHelper logHelper)
        {
            var account = new Account(
                configuration["Cloudinary:CloudName"],
                configuration["Cloudinary:ApiKey"],
                configuration["Cloudinary:ApiSecret"]
            );
            _cloudinary = new Cloudinary(account);
            _logger = logHelper.GetLogger<CloudinaryService>();
        }

        public async Task<string> UploadImageAsync(LoggingProperties loggingProperties,Stream fileStream, string fileName)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
               .Debug(LogMessages.MethodStart, nameof(UploadImageAsync));

                var uploadParams = new ImageUploadParams
                {
                    File = new FileDescription(fileName, fileStream),
                    Folder = "uploads" 
                };

                var uploadResult = await _cloudinary.UploadAsync(uploadParams);
                return uploadResult.SecureUrl.AbsoluteUri; 
            }
            catch (Exception ex) {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorOccured, nameof(UploadImageAsync), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(UploadImageAsync), watch.Elapsed.TotalSeconds);
            }

        }
    }
}
