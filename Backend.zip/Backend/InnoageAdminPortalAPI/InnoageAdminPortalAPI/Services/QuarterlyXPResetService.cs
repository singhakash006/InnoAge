﻿
using InnoageAdminPortalAPI.Repository;

namespace InnoageAdminPortalAPI.Services
{
    public class QuarterlyXPResetService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public QuarterlyXPResetService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await CheckAndResetXP();

                // Sleep for 24 hours before checking again
                await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
            }
        }

        private async Task CheckAndResetXP()
        {
            DateTime now = DateTime.UtcNow;
            if (now.Day == 1 && (now.Month == 1 || now.Month == 4 || now.Month == 7 || now.Month == 10))
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    var cartRepository = scope.ServiceProvider.GetRequiredService<CartRepository>();

                    Console.WriteLine(" Resetting XP for all users...");
                    await cartRepository.ResetAllXPAsync();
                    //await cartRepository.ResetAllXPGivenAsync();
                }
            }
        }
    }
}


//now.Day == 1 && (now.Month == 1 || now.Month == 4 || now.Month == 7 || now.Month == 10
