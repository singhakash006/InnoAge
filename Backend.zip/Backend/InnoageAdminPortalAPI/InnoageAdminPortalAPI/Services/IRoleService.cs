﻿using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Entity;

namespace InnoageAdminPortalAPI.Services
{
    public interface IRoleService
    {
        Task<Role?> GetRoleByIdAsync(LoggingProperties loggingProperties, string roleId);
    }
}
