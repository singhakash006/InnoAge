﻿using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    
    
        public interface ICloudinaryService
        {
            Task<string> UploadImageAsync(LoggingProperties loggingProperties, Stream fileStream, string fileName);
        }
    
}
