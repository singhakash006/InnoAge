﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Services
{
    public interface IDepartmentService
    {
        Task<Department?> GetDepartmentByIdAsync(LoggingProperties loggingProperties, string departmentId);
    }
}
