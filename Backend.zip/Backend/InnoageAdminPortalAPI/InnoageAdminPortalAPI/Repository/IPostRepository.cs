﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface IPostRepository
    {
        Task<List<DashboardDto>> GetAllPost(LoggingProperties loggingProperties, DateTime? lastFetchedDate, int limit = 10);
        Task<string> InsertPost(LoggingProperties loggingProperties, Posts post);
        Task<string> UpdatePoll(LoggingProperties loggingProperties, PollDto poll);
    }
}
