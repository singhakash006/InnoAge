﻿using AutoMapper;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Diagnostics;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public class NominationRepository:BaseRepository<Nomination>,INominationRepository
    {
        public const string CollectionName = Collections.Nominations;
        private readonly ILogger _logger;
        private readonly IMapper _mapper;

        public NominationRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper, IMapper mapper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<NominationRepository>();
            _mapper = mapper;
        }

        public override string DbCollectionName => CollectionName;

        public async Task<List<Nomination>> GetAllNominationsAsync()
        {
            return await Collection.Find(_ => true).ToListAsync();
        }

        public async Task<Nomination?> GetNominationByIdAsync(string id)
        {
            return await Collection.Find(n => n.Id == id).FirstOrDefaultAsync();
        }

        public async Task AddNominationAsync(Nomination nomination)
        {
            await Collection.InsertOneAsync(nomination);
        }

       

        public async Task<List<Nomination>> GetNominationsByTypeAsync(LoggingProperties loggingProperties, string nominationType)
        {
            var startDate = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
            var endDate = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 25, 23, 59, 59);

            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching nominations by type '{NominationType}' between {StartDate} and {EndDate}.",
                             nominationType, startDate, endDate);

            var filter = Builders<Nomination>.Filter.And(
                Builders<Nomination>.Filter.Eq(n => n.Nomination_Type, nominationType),
                Builders<Nomination>.Filter.Gte(n => n.CreatedAt, startDate),
                Builders<Nomination>.Filter.Lte(n => n.CreatedAt, endDate)
            );

            var nominations = await Collection.Find(filter).ToListAsync();

            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetched {Count} nominations of type '{NominationType}'.", nominations.Count, nominationType);

            return nominations;
        }

        public async Task<List<Nomination>> GetNominationsAsync(LoggingProperties loggingProperties, string nominationType)
        {
            var now = DateTime.UtcNow;
            var startOfMonth = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
            var midMonth = new DateTime(now.Year, now.Month, 25, 23, 59, 59, DateTimeKind.Utc);

            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching unverified nominations of type '{NominationType}' from {StartOfMonth} to {MidMonth}.",
                             nominationType, startOfMonth, midMonth);

            var filter = Builders<Nomination>.Filter.And(
                Builders<Nomination>.Filter.Eq(n => n.Nomination_Type, nominationType),
                Builders<Nomination>.Filter.Eq(n => n.isApproved, false),
                Builders<Nomination>.Filter.Gte(n => n.CreatedAt, startOfMonth),
                Builders<Nomination>.Filter.Lte(n => n.CreatedAt, midMonth)
            );

            var nominations = await Collection.Find(filter).ToListAsync();

            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetched {Count} unverified nominations of type '{NominationType}'.", nominations.Count, nominationType);

            return nominations;
        }

        public async Task<bool> SelectFromNominatedEmployeesAsync(LoggingProperties loggingProperties, string nominationType, string userId)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Selecting user '{UserId}' for nomination type '{NominationType}'.", userId, nominationType);

            if (!ObjectId.TryParse(userId, out ObjectId userObjectId))
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Warning("Invalid User ID format: {UserId}.", userId);
                throw new ArgumentException("Invalid User ID format. It should be a valid ObjectId.");
            }

            var filter = Builders<Nomination>.Filter.Eq(n => n.Nomination_Type, nominationType) &
                         Builders<Nomination>.Filter.Eq(n => n.UserId, userObjectId.ToString());

            var update = Builders<Nomination>.Update
                .Set(n => n.isApproved, true)
                .Set(n => n.VerifiedAt, DateTime.UtcNow);

            var result = await Collection.UpdateOneAsync(filter, update);

            if (result.ModifiedCount > 0)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully verified nomination for user '{UserId}' of type '{NominationType}'.", userId, nominationType);
            }
            else
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Warning("No nomination record found to verify for user '{UserId}' of type '{NominationType}'.", userId, nominationType);
            }

            return result.ModifiedCount > 0;
        }
        public async Task<List<DashboardDto>> GetAllNominationsByLatestTime(LoggingProperties loggingProperties, DateTime? lastFetchedDate, int limit = 10)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .Debug(LogMessages.MethodStart, nameof(GetAllNominationsByLatestTime));

                var filter = lastFetchedDate.HasValue
                ? Builders<Nomination>.Filter.Lt(a => a.VerifiedAt, lastFetchedDate.Value)
                : Builders<Nomination>.Filter.Empty;

                var validation = Builders<Nomination>.Filter.Eq(a => a.isApproved, true);

                var NominationQuery = Collection.Aggregate()
                    .Match(filter)
                    .Match(validation)
                    .Lookup("User", "UserId", "_id", "UserId")
                    .Unwind("UserId", new AggregateUnwindOptions<BsonDocument> { PreserveNullAndEmptyArrays = true })
                    .Lookup("User", "Nominated_By", "_id", "Nominated_By")
                    .Unwind("Nominated_By", new AggregateUnwindOptions<BsonDocument> { PreserveNullAndEmptyArrays = true })
                    .Lookup("Comments", "_id", "Posts", "postComments")
                    .Lookup("likes", "_id", "Posts", "postLikes")
                    .Project(new BsonDocument {
                    { "_id", 1 },
                    { "Nomination_Type", 1 },
                    { "Reason", 1 },
                    { "CreatedAt", 1 },
                    { "VerifiedAt", 1 },
                    { "UserId", "$UserId.Name" },
                    { "Nominated_By", "$Nominated_By.Name"},
                    {"isApproved", 1 },
                    { "postComments", 1 },
                    { "postLikes", 1 } })
                    .Sort(Builders<BsonDocument>.Sort.Descending("VerifiedAt"))
                    .Limit(10)
                    .As<NominationGetDto>();

                var NominationList = await NominationQuery.ToListAsync();

                return NominationList.Select(item => new DashboardDto { NominationData = item }).ToList();


            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                      .Error(ex, LogMessages.ErrorOccured, nameof(GetAllNominationsByLatestTime), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(GetAllNominationsByLatestTime), watch.Elapsed.TotalSeconds);
            }
        }
    }
}