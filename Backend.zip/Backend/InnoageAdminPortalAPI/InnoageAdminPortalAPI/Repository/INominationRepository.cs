﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface INominationRepository
    {
        Task<List<Nomination>> GetAllNominationsAsync();
        Task<Nomination?> GetNominationByIdAsync(string id);
        Task AddNominationAsync(Nomination nomination);
        
        Task<List<Nomination>> GetNominationsByTypeAsync(LoggingProperties loggingProperties, string nominationType);
        Task<List<DashboardDto>> GetAllNominationsByLatestTime(LoggingProperties loggingProperties, DateTime? lastFetchedDate, int limit = 10);
        Task<List<Nomination>> GetNominationsAsync(LoggingProperties loggingProperties, string nominationType);
        Task<bool> SelectFromNominatedEmployeesAsync(LoggingProperties loggingProperties, string nominationType, string userId);
    }
}
