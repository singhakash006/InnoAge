﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface IPasswordResetRepository
    {
        Task SaveResetTokenAsync(LoggingProperties loggingProperties, string email, string token, DateTime expiry);
        Task<PasswordResetToken?> GetValidResetTokenAsync(LoggingProperties loggingProperties, string token);
        Task DeleteResetTokenAsync(LoggingProperties loggingProperties, string token);
        Task DeleteResetTokenByEmailAsync(LoggingProperties loggingProperties, string email);
    }
}
