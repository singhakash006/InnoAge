﻿using MongoDB.Driver;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Helpers;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;
using InnoageAdminPortalAPI.Models;
using System.Diagnostics;
using InnoageAdminPortalAPI.Constants;


namespace InnoageAdminPortalAPI.Repository
{
    public class UserRepository:BaseRepository<User>, IUserRepository
    {
        public const string CollectionName = Collections.User;
        private readonly ILogger _logger;
        private readonly IRoleRepository _roleRepository;


        public UserRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper, IRoleRepository roleRepository)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<UserRepository>();
            _roleRepository = roleRepository;
        }

        public override string DbCollectionName => CollectionName;

     

        public async Task<List<User>> GetEmployeeByTeamId(LoggingProperties loggingProperties, string teamId, string roleId)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching employees with Role ID: {RoleId} for Team ID: {TeamId}", roleId, teamId);

            try
            {
                var filter = Builders<User>.Filter.And(
                    Builders<User>.Filter.Eq(user => user.TeamId, teamId),
                    Builders<User>.Filter.Eq(user => user.RoleId, roleId)
                );

                var employees = await Collection.Find(filter).ToListAsync();

                if (employees.Any())
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Found {EmployeeCount} employees for Team ID: {TeamId} with Role ID: {RoleId}", employees.Count, teamId, roleId);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No employees found for Team ID: {TeamId} with Role ID: {RoleId}", teamId, roleId);
                }

                return employees;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching employees for Team ID: {TeamId} with Role ID: {RoleId}", teamId, roleId);
                throw;
            }
        }


        public async Task<List<User>> GetTLs(LoggingProperties loggingProperties)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching all Team Leaders from the database.");

            try
            {
                // Fetch the Role ID for "TeamLeader"
                string? teamLeaderRoleId = await _roleRepository.GetIdByRoleAsync(loggingProperties, "TeamLeader");

                if (string.IsNullOrEmpty(teamLeaderRoleId))
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No 'TeamLeader' role found in the database.");
                    return new List<User>(); // No Team Leader role found
                }

                // Filter users who have the Team Leader role
                var filter = Builders<User>.Filter.Eq(user => user.RoleId, teamLeaderRoleId);
                var teamLeaders = await Collection.Find(filter).ToListAsync();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully fetched {Count} Team Leaders.", teamLeaders.Count);

                return teamLeaders;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching Team Leaders.");
                throw;
            }
        }







        public async Task<User?> GetByEmailAsync(LoggingProperties loggingProperties, string email)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching user with Email: {Email}", email);

            try
            {
                var user = await Collection.Find(emp => emp.Email == email).FirstOrDefaultAsync();

                if (user != null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("User found with Email: {Email}, UserId: {UserId}", email, user.Id);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No user found with Email: {Email}", email);
                }

                return user;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching user with Email: {Email}", email);
                throw;
            }
        }


  




        public async Task<User?> GetByIdAsync(LoggingProperties loggingProperties, string id)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .Debug(LogMessages.MethodStart, nameof(GetByIdAsync));
                var user = await Collection.Find(user => user.Id == id).FirstOrDefaultAsync();
                return user;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorOccured, nameof(GetByIdAsync), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(GetByIdAsync), watch.Elapsed.TotalSeconds);
            }

        }

        public async Task<string?> GetEmailByIdAsync(LoggingProperties loggingProperties, string id)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching email for user. User ID: {UserId}", id);

            try
            {
                var user = await Collection.Find(user => user.Id == id).FirstOrDefaultAsync();

                if (user == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("User not found while fetching email. User ID: {UserId}", id);
                    return null;
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully retrieved user email. User ID: {UserId}, Email: {UserEmail}", id, user.Email);

                return user.Email;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching email for user. User ID: {UserId}", id);
                throw;
            }
        }


        public async Task AddAsync(LoggingProperties loggingProperties, User user)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Attempting to add new user. Email: {Email}, RoleId: {RoleId}", user.Email, user.RoleId);

            try
            {
                await Collection.InsertOneAsync(user);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully added new user. UserId: {UserId}, Email: {Email}", user.Id, user.Email);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while adding user. Email: {Email}", user.Email);
                throw;
            }
        }


        public async Task<bool> UpdatePasswordAsync(LoggingProperties loggingProperties, string email, string newPasswordHash)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Attempting to update password for user. Email: {Email}", email);

            try
            {
                var update = Builders<User>.Update.Set(user => user.Password, newPasswordHash);
                var result = await Collection.UpdateOneAsync(user => user.Email == email, update);

                if (result.ModifiedCount > 0)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully updated password for user. Email: {Email}", email);
                    return true;
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No password update performed. Email might be incorrect. Email: {Email}", email);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while updating password for user. Email: {Email}", email);
                throw;
            }
        }


        public async Task<string> GetTeamByIdAsync(LoggingProperties loggingProperties, string id)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching team ID for user. User ID: {UserId}", id);

            try
            {
                var user = await Collection.Find(user => user.Id == id).FirstOrDefaultAsync();

                if (user == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("User not found while fetching team ID. User ID: {UserId}", id);
                    return string.Empty; // Return empty string if user not found
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully retrieved team ID. User ID: {UserId}, Team ID: {TeamId}", id, user.TeamId);

                return user.TeamId;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching team ID for user. User ID: {UserId}", id);
                throw;
            }
        }


        public async Task<bool> UpdateUserProfileAsync(FilterDefinition<User> filter, UpdateDefinition<User> update)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.Debug(LogMessages.MethodStart, nameof(UpdateUserProfileAsync));
                var result = await Collection.UpdateOneAsync(filter, update);
                return result.ModifiedCount > 0;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, LogMessages.ErrorOccured, nameof(UpdateUserProfileAsync), ex.Message);
                throw;
            }
            finally
            {
                watch.Stop();
                _logger.Debug(LogMessages.MethodEnd, nameof(UpdateUserProfileAsync), watch.Elapsed.TotalSeconds);
            }
        }

        public async Task<User?> GetByEmpIdAsync(string EmpId)
        {
            return await Collection.Find(emp => emp.EmployeeId == EmpId).FirstOrDefaultAsync();

        }



    }
}
