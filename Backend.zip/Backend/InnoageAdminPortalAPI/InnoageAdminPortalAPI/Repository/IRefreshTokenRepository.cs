﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface IRefreshTokenRepository
    {
        bool IsTokenUniqueAsync(string token);

        Task AssociateRefreshTokenAsync(LoggingProperties logging, RefreshToken refreshToken);

        Task DeleteOldRefreshTokenAsync(LoggingProperties loggingProperties, string userId, int TTL);
    }
}
