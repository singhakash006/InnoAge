﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface ITeamRepository
    {
        Task<List<Team>> GetAllAsync(LoggingProperties loggingProperties);
        Task<Team?> GetByIdAsync(LoggingProperties loggingProperties, string id);
        Task<string?> GetTeamLeaderIdByTeamIdAsync(LoggingProperties loggingProperties, string id);
    }
}
