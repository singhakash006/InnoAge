﻿using MongoDB.Driver;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Helpers;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;
using MongoDB.Bson;
using System.Diagnostics;
using InnoageAdminPortalAPI.Constants;
using AutoMapper;

namespace InnoageAdminPortalAPI.Repository
{
    public class PostRepository:BaseRepository<Posts>, IPostRepository
    {
        public const string CollectionName = Collections.Dashboard;
        private readonly ILogger _logger;
        private readonly IMapper _mapper;

        public PostRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper, IMapper mapper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<PostRepository>();
            _mapper = mapper;
        }

        public override string DbCollectionName => CollectionName;


        public async Task<List<DashboardDto>> GetAllPost(LoggingProperties loggingProperties, DateTime? lastFetchedDate, int limit = 10)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .Debug(LogMessages.MethodStart, nameof(GetAllPost));

                var filter = lastFetchedDate.HasValue ? Builders<Posts>.Filter.Lt(a => a.created_at, lastFetchedDate.Value.ToUniversalTime()) :
                              Builders<Posts>.Filter.Empty;



                var postsQuery = Collection.Aggregate()
                .Match(filter) 
                .Lookup("Comments", "_id", "Posts", "postComments") 
                .Lookup("likes", "_id", "Posts", "postLikes") 
                .As<PostGetDto>()
                .SortByDescending(a => a.created_at) 
                .Limit(limit);

                var postList = await postsQuery.ToListAsync();

                return postList.Select(item => new DashboardDto { PostData = item }).ToList();
                
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorOccured, nameof(GetAllPost), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(GetAllPost), watch.Elapsed.TotalSeconds);
            }
        }


        public async Task<string> InsertPost(LoggingProperties loggingProperties, Posts post)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .Debug(LogMessages.MethodStart, nameof(InsertPost));
                await Collection.InsertOneAsync(post);
                
                return "Post SuccessFull Insert";
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Error(ex, LogMessages.ErrorOccured, nameof(InsertPost), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(InsertPost), watch.Elapsed.TotalSeconds);
            }

        }

        public async Task<string> UpdatePoll(LoggingProperties loggingProperties, PollDto poll)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .ForContext(LogProperties.UserId, loggingProperties.UserId)
                     .Debug(LogMessages.MethodStart, nameof(UpdatePoll));

                var filterByPostId = Builders<Posts>.Filter.Eq(p => p.Id, poll.postId);

                
                var filterForYes = Builders<Posts>.Filter.And(
                    filterByPostId,
                    Builders<Posts>.Filter.ElemMatch(p => p.totalYes, vote => vote.userId == poll.userId)
                );

                var userExistInYes = await Collection.Find(filterForYes).AnyAsync();

               
                var filterForNo = Builders<Posts>.Filter.And(
                    filterByPostId,
                    Builders<Posts>.Filter.ElemMatch(p => p.totalNo, vote => vote.userId == poll.userId)
                );

                var userExistInNo = await Collection.Find(filterForNo).AnyAsync();

                
                if (poll.voteType == "No")
                {
                    if (userExistInYes)
                    {
                        var removeFromYes = Builders<Posts>.Update.PullFilter(p => p.totalYes, vote => vote.userId == poll.userId);
                        await Collection.UpdateOneAsync(filterForYes, removeFromYes);
                    }

                    var addToNo = Builders<Posts>.Update.Push(p => p.totalNo, new PollVotes { userId = poll.userId });
                    await Collection.UpdateOneAsync(filterByPostId, addToNo);
                    
                    return "Vote successfully updated for No";
                }
                else if (poll.voteType == "Yes")
                {
                    if (userExistInNo)
                    {
                        var removeFromNo = Builders<Posts>.Update.PullFilter(p => p.totalNo, vote => vote.userId == poll.userId);
                        await Collection.UpdateOneAsync(filterForNo, removeFromNo);
                    }

                    var addToYes = Builders<Posts>.Update.Push(p => p.totalYes, new PollVotes { userId = poll.userId });
                    await Collection.UpdateOneAsync(filterByPostId, addToYes);
                    
                    return "Vote successfully updated for Yes";
                }
                
                return "Invalid vote type";
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                         .ForContext(LogProperties.UserId, loggingProperties.UserId)
                        .Error(ex, LogMessages.ErrorOccured, nameof(UpdatePoll), ex.Message);
                throw ex;

            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                    .Debug(LogMessages.MethodEnd, nameof(UpdatePoll), watch.Elapsed.TotalSeconds);
            }

        }

    }
}
