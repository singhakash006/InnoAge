﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface ILikeRepository
    {       
        Task<string> InsertLike(LoggingProperties loggingProperties, LikeDto like);
        
    }
}
