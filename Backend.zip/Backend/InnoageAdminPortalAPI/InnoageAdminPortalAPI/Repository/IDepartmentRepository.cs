﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface IDepartmentRepository
    {
        Task<Department?> GetDepartmentByIdAsync(LoggingProperties loggingProperties, string departmentId);
    }
}
