﻿
using AutoMapper;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using Microsoft.Extensions.Hosting;
using MongoDB.Driver;
using System.Diagnostics;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Repository
{
    public class CommentRepository:BaseRepository<Comment>,ICommentRepository
    {
        public const string CollectionName = Collections.Comments;
        private readonly ILogger _logger;
        private IMapper _mapper;

        public CommentRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper, IMapper mapper)
: base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<CommentRepository>();
            _mapper = mapper;
        }

        public override string DbCollectionName => CollectionName;

        public async Task<string> InsertComment(LoggingProperties loggingProperties, CommentDto comment)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .Debug(LogMessages.MethodStart, nameof(InsertComment));


                var commentData = _mapper.Map<Comment>(comment);

                await Collection.InsertOneAsync(commentData);

                return "Comment inserted successfully";
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorOccured, nameof(InsertComment), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(InsertComment), watch.Elapsed.TotalSeconds);
            }
        }

    }

}
