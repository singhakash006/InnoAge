﻿using IdentityModel.Client;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using MongoDB.Driver;
using System.Diagnostics;
using static InnoageAdminPortalAPI.Constants.Constants;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
namespace InnoageAdminPortalAPI.Repository
{
    public class RefreshTokenRepository : BaseRepository<RefreshToken>, IRefreshTokenRepository
    {
        public const string CollectionName = Collections.RefreshToken;
        private readonly Serilog.ILogger _logger;


        public RefreshTokenRepository(
            IConfiguration configuration,
            IMongoClient mongoClient,
            ILogHelper logHelper)
            : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<RefreshTokenRepository>();
        }

        public override string DbCollectionName => CollectionName;

        public async Task AssociateRefreshTokenAsync(LoggingProperties loggingProperties, RefreshToken refreshToken)
        {
            var watch = Stopwatch.StartNew();
            try
            {

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.MethodStart, nameof(AssociateRefreshTokenAsync));

                await Collection.InsertOneAsync(refreshToken);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                        .Debug(LogMessages.AddSuccess, refreshToken.Id, CollectionName);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                     .Error(ex, LogMessages.ErrorOccured, nameof(AssociateRefreshTokenAsync), ex.Message);

                throw;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                    .Debug(LogMessages.MethodEnd, nameof(AssociateRefreshTokenAsync), watch.Elapsed.TotalSeconds);
            }
        }

        public async Task DeleteOldRefreshTokenAsync(LoggingProperties loggingProperties, string userId, int TTL)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.MethodStart, nameof(DeleteOldRefreshTokenAsync));

                await Collection.DeleteManyAsync(x => x.UserId == userId && x.Expires <= DateTime.UtcNow);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.DeleteSuccess, userId, CollectionName);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Error(ex, LogMessages.ErrorOccured, nameof(DeleteOldRefreshTokenAsync), ex.Message);

                throw;
            }
            finally
            {
                watch.Stop();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                       .Debug(LogMessages.MethodEnd, nameof(DeleteOldRefreshTokenAsync), watch.Elapsed.TotalSeconds);
            }
        }

        public bool IsTokenUniqueAsync(string token)
        {
            try
            {
                return !Collection.Find(x => x.Token == token).Any();
            }
            catch (Exception)
            {
                return false;
            }
        }

        protected async override void DefineIndexes()
        {
            var indexKeysDefinition = Builders<RefreshToken>.IndexKeys.Ascending(token => token.UserId);
            var indexOptions = new CreateIndexOptions() { };
            await Collection.Indexes.CreateOneAsync(new CreateIndexModel<RefreshToken>(indexKeysDefinition, indexOptions));
        }
    }
}
