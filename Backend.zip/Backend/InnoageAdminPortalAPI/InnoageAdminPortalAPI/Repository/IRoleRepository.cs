﻿using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Entity;

namespace InnoageAdminPortalAPI.Repository
{
    public interface IRoleRepository
    {
        Task<Role?> GetByIdAsync(LoggingProperties loggingProperties, string id);
        Task<string?> GetIdByRoleAsync(LoggingProperties loggingProperties, string roleName);
    }
}
