using MongoDB.Driver;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
using static InnoageAdminPortalAPI.Constants.Constants;
using System.Diagnostics;
using ILogger = Serilog.ILogger;
using InnoageAdminPortalAPI.Models;
namespace InnoageAdminPortalAPI.Repository;

public class SocialActivityRepository : BaseRepository<ActivityCalendar>, ISocialActivityRepository
{
    public const string CollectionName = Collections.ActivityCalendar;
    private readonly ILogger _logger;


    public SocialActivityRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper)
   : base(configuration, mongoClient)
    {
        _logger = logHelper.GetLogger<UserRepository>();
    }

    public override string DbCollectionName => CollectionName;


    public async Task AddActivityAsync(ActivityCalendar activityEntity, LoggingProperties loggingProperties)
    {
        var watch = Stopwatch.StartNew();
        try
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Debug(LogMessages.MethodStart, nameof(AddActivityAsync));

            await Collection.InsertOneAsync(activityEntity);

            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Information("Activity successfully added: {ActivityName}", activityEntity.ActivityName);
        }
        catch (MongoException ex)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, "MongoDB Error while adding activity: {ErrorMessage}", ex.Message);

            throw new Exception("Database error occurred while adding the activity.", ex);
        }
        catch (Exception ex)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, "Unexpected error in {MethodName}: {ErrorMessage}", nameof(AddActivityAsync), ex.Message);

            throw new Exception("An unexpected error occurred while adding the activity.", ex);
        }
        finally
        {
            watch.Stop();
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Debug(LogMessages.MethodEnd, nameof(AddActivityAsync), watch.Elapsed.TotalSeconds);
        }
    }

    public async Task<PaginatedResponse<ActivityCalendar>> GetActivitiesByCategoryAsync(LoggingProperties loggingProperties, string category, int pageNumber, int pageSize)
    {
        var watch = Stopwatch.StartNew();
        try
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Debug(LogMessages.MethodStart, nameof(GetActivitiesByCategoryAsync));

            var filter = Builders<ActivityCalendar>.Filter.Eq("Category", category);

            var totalRecords = await Collection.CountDocumentsAsync(filter);

            var activities = await Collection
                .Find(filter)
                .Skip((pageNumber - 1) * pageSize)
                .Limit(pageSize)
                .ToListAsync();

            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Information("Fetched {Count} activities for category: {Category} on page {PageNumber}", activities.Count, category, pageNumber);

            return new PaginatedResponse<ActivityCalendar>
            {
                Data = activities,
                TotalRecords = (int)totalRecords,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }
        catch (MongoException ex)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, "MongoDB Error while fetching activities: {ErrorMessage}", ex.Message);

            throw new Exception("Database error occurred while fetching activities.", ex);
        }
        catch (Exception ex)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, "Unexpected error in {MethodName}: {ErrorMessage}", nameof(GetActivitiesByCategoryAsync), ex.Message);

            throw new Exception("An unexpected error occurred while fetching activities.", ex);
        }
        finally
        {
            watch.Stop();
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Debug(LogMessages.MethodEnd, nameof(GetActivitiesByCategoryAsync), watch.Elapsed.TotalSeconds);
        }
    }

}