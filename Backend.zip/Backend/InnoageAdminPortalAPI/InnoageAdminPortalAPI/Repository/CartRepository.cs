﻿
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using MongoDB.Driver;
using ILogger = Serilog.ILogger;
using static InnoageAdminPortalAPI.Constants.Constants;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Constants;
using System.Diagnostics;

namespace InnoageAdminPortalAPI.Repository
{
    public class CartRepository :BaseRepository<Cart>, ICartRepository
    {
        public const string CollectionName = Collections.Cart;
        private readonly ILogger _logger;


        public CartRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<CartRepository>();
        }

        public override string DbCollectionName => CollectionName;


        public async Task<int> GetXPAsync(LoggingProperties loggingProperties, string cartId)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.GetXPAsync), new { CartId = cartId });

                var cart = await Collection.Find(c => c.Id == cartId).FirstOrDefaultAsync();

                if (cart == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Cart not found for CartId: {CartId}", cartId);
                    return 0;
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("XP retrieved for CartId: {CartId}, XPs: {XPs}", cartId, cart.XPs);

                return cart.XPs;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.GetXPAsync), ex.Message);

                return 0; // Return 0 to handle failures gracefully
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.GetXPAsync), watch.Elapsed.TotalSeconds);
            }
        }


        public async Task<bool> DecrementXPAsync(LoggingProperties loggingProperties, string CartId)
        {
            var watch = Stopwatch.StartNew();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.DecrementXPAsync));

                var update = Builders<Cart>.Update.Inc(c => c.XPs, -1);
                var filter = Builders<Cart>.Filter.And(
                    Builders<Cart>.Filter.Eq(c => c.Id, CartId),
                    Builders<Cart>.Filter.Gt(c => c.XPs, 0)
                );

                var result = await Collection.UpdateOneAsync(filter, update);
                bool isDecremented = result.ModifiedCount > 0;

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("XP decrement {Status} for CartId: {CartId}", isDecremented ? "successful" : "failed", CartId);

                return isDecremented;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.DecrementXPAsync), ex.Message);
                return false;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.DecrementXPAsync), watch.Elapsed.TotalSeconds);
            }
        }




        public async Task ResetAllXPAsync()
        {
            var update = Builders<Cart>.Update.Set(c => c.XPs, 5); // Set XP to 5 for all users
            await Collection.UpdateManyAsync(FilterDefinition<Cart>.Empty, update);
        }

        public async Task<Cart> CreateCartAsync(LoggingProperties loggingProperties)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Starting cart creation process.");

            var newCart = new Cart
            {
                XPs = 999 // Set initial XPs
            };

            try
            {
                await Collection.InsertOneAsync(newCart);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("New cart created successfully. CartId: {CartId}", newCart.Id);

                return newCart;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while creating a new cart.");

                throw;
            }
        }



    }
}
