﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models.ReponseModels;
using MongoDB.Driver;

namespace InnoageAdminPortalAPI.Repository
{
    public interface IUserRepository
    {
        Task<List<User>> GetEmployeeByTeamId(LoggingProperties loggingProperties, string teamId, string roleId);
        Task<List<User>> GetTLs(LoggingProperties loggingProperties);
        Task<User?> GetByEmailAsync(LoggingProperties loggingProperties, string email);
        Task<User?> GetByIdAsync(LoggingProperties loggingProperties, string id);
        Task<string?> GetEmailByIdAsync(LoggingProperties loggingProperties, string id);
        Task AddAsync(LoggingProperties loggingProperties, User user);
        Task<bool> UpdatePasswordAsync(LoggingProperties loggingProperties, string email, string newPasswordHash);
        Task<string> GetTeamByIdAsync(LoggingProperties loggingProperties, string id);
        Task<bool> UpdateUserProfileAsync(FilterDefinition<User> filter, UpdateDefinition<User> update);
        Task<User?> GetByEmpIdAsync(string EmpId);


    }
}
