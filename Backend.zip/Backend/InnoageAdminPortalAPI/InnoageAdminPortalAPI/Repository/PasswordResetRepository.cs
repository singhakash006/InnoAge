﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using MongoDB.Driver;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Repository
{
    public class PasswordResetRepository:BaseRepository<PasswordResetToken>, IPasswordResetRepository
    {
        public const string CollectionName = Collections.PasswordReset;
        private readonly ILogger _logger;


        public PasswordResetRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<PasswordResetRepository>();
        }

        public override string DbCollectionName => CollectionName;

        public async Task SaveResetTokenAsync(LoggingProperties loggingProperties, string email, string token, DateTime expiry)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Saving password reset token for Email: {Email} with Expiry: {Expiry}", email, expiry);

            try
            {
                var resetToken = new PasswordResetToken
                {
                    Email = email,
                    Token = token,
                    ExpiresAt = expiry
                };

                await Collection.InsertOneAsync(resetToken);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully saved password reset token for Email: {Email}", email);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while saving password reset token for Email: {Email}", email);
                throw;
            }
        }

        public async Task<PasswordResetToken?> GetValidResetTokenAsync(LoggingProperties loggingProperties, string token)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching valid reset token for Token: {Token}", token);

            try
            {
                var resetToken = await Collection.Find(t => t.Token == token && t.ExpiresAt > DateTime.UtcNow)
                                                 .FirstOrDefaultAsync();

                if (resetToken == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No valid reset token found for Token: {Token}", token);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Valid reset token found for Token: {Token}", token);
                }

                return resetToken;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching reset token for Token: {Token}", token);
                throw;
            }
        }

        public async Task DeleteResetTokenAsync(LoggingProperties loggingProperties, string token)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Deleting reset token for Token: {Token}", token);

            try
            {
                var result = await Collection.DeleteOneAsync(t => t.Token == token);

                if (result.DeletedCount > 0)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully deleted reset token for Token: {Token}", token);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No reset token found to delete for Token: {Token}", token);
                }
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while deleting reset token for Token: {Token}", token);
                throw;
            }
        }

        public async Task DeleteResetTokenByEmailAsync(LoggingProperties loggingProperties, string email)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Deleting reset token for Email: {Email}", email);

            try
            {
                var result = await Collection.DeleteOneAsync(t => t.Email == email);

                if (result.DeletedCount > 0)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully deleted reset token for Email: {Email}", email);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No reset token found to delete for Email: {Email}", email);
                }
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while deleting reset token for Email: {Email}", email);
                throw;
            }
        }

    }
}
