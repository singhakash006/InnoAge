﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface ICartRepository
    {
        //Task<Cart?> GetCartByIdAsync(LoggingProperties loggingProperties, string cartId);
        Task<int> GetXPAsync(LoggingProperties loggingProperties, string CartId);

        Task<bool> DecrementXPAsync(LoggingProperties loggingProperties, string CartId);

        Task ResetAllXPAsync();

        Task<Cart> CreateCartAsync(LoggingProperties loggingProperties);

    }
}
