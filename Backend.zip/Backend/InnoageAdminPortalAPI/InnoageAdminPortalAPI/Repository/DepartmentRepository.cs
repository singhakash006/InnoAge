﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using MongoDB.Driver;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Repository
{
    public class DepartmentRepository : BaseRepository<Department>, IDepartmentRepository
    {


        public const string CollectionName = Collections.Department;
        private readonly ILogger _logger;


        public DepartmentRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<DepartmentRepository>();
        }

        public override string DbCollectionName => CollectionName;

        public async Task<Department?> GetDepartmentByIdAsync(LoggingProperties loggingProperties, string departmentId)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching department details for DepartmentId: {DepartmentId}", departmentId);

            try
            {
                var department = await Collection.Find(dept => dept.Id == departmentId).FirstOrDefaultAsync();

                if (department == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Department not found for DepartmentId: {DepartmentId}", departmentId);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully retrieved department details for DepartmentId: {DepartmentId}", departmentId);
                }

                return department;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching department details for DepartmentId: {DepartmentId}", departmentId);

                throw;
            }
        }


    }
}
