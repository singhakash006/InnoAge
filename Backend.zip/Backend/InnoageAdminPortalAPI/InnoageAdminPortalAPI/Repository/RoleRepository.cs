﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using MongoDB.Driver;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Repository
{
    public class RoleRepository : BaseRepository<Role>, IRoleRepository
    {
        public const string CollectionName = Collections.Role;
        private readonly ILogger _logger;

        public RoleRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper)
            : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<RoleRepository>();
        }

        public override string DbCollectionName => CollectionName;

        public async Task<Role?> GetByIdAsync(LoggingProperties loggingProperties, string id)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching role details for RoleId: {RoleId}", id);

            try
            {
                var role = await Collection.Find(role => role.Id == id).FirstOrDefaultAsync();

                if (role == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No role found for RoleId: {RoleId}", id);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully fetched role details for RoleId: {RoleId}", id);
                }

                return role;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching role details for RoleId: {RoleId}", id);
                throw;
            }
        }


        public async Task<string?> GetIdByRoleAsync(LoggingProperties loggingProperties, string roleName)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching Role ID for role: {RoleName}.", roleName);

            try
        {
            var role = await Collection.Find(role => role.RoleName == roleName).FirstOrDefaultAsync();

                if (role == null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No role found for RoleName: {RoleName}.", roleName);
                    return null;
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully fetched Role ID: {RoleId} for RoleName: {RoleName}.", role.Id, roleName);

                return role.Id;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching Role ID for RoleName: {RoleName}.", roleName);
                throw;
            }
        }

        //public async Task CreateAsync(Role role) =>
        //    await Collection.InsertOneAsync(role);

        //public async Task<bool> UpdateAsync(string id, Role updatedRole)
        //{
        //    var result = await Collection.ReplaceOneAsync(role => role.Id == id, updatedRole);
        //    return result.ModifiedCount > 0;
        //}

        //public async Task<bool> DeleteAsync(string id)
        //{
        //    var result = await Collection.DeleteOneAsync(role => role.Id == id);
        //    return result.DeletedCount > 0;
        //}
    }
}
