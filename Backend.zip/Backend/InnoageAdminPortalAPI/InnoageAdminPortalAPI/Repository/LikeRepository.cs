﻿using AutoMapper;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using Microsoft.Extensions.Hosting;
using MongoDB.Driver;
using System.Diagnostics;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Repository
{
    public class LikeRepository:BaseRepository<Like>,ILikeRepository
    {
        public const string CollectionName = Collections.Likes;
        private readonly ILogger _logger;
        private readonly IMapper _mapper;

        public LikeRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper, IMapper mapper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<LikeRepository>();
            _mapper = mapper;
        }
        public override string DbCollectionName => CollectionName;

        public async Task<string> InsertLike(LoggingProperties loggingProperties, LikeDto like)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                     .ForContext(LogProperties.UserId, loggingProperties.UserId)
                     .Debug(LogMessages.MethodStart, nameof(InsertLike));

                var newLike = _mapper.Map<Like>(like);
                await Collection.InsertOneAsync(newLike);   
                return "Like updated successfully";

            }
            catch (Exception ex) {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                         .ForContext(LogProperties.UserId, loggingProperties.UserId)
                        .Error(ex, LogMessages.ErrorOccured, nameof(InsertLike), ex.Message);
                throw ex;
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .ForContext(LogProperties.UserId, loggingProperties.UserId)
                    .Debug(LogMessages.MethodEnd, nameof(InsertLike), watch.Elapsed.TotalSeconds);
            }
        }
    }
}
