﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.Repository
{
    public interface ICommentRepository
    {   
            Task<string> InsertComment(LoggingProperties loggingProperties,CommentDto comment);
        
    }
}
