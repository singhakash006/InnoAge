﻿using MongoDB.Driver;
using System.Diagnostics.CodeAnalysis;
using static InnoageAdminPortalAPI.Constants.Constants;





namespace InnoageAdminPortalAPI.Repository
{
    
    /// <summary>
    /// Base Repository for MongoDB Connections.
    /// </summary>
    /// <typeparam name="T">Collection Name.</typeparam>
    [ExcludeFromCodeCoverage]
    public abstract class BaseRepository<T>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository{T}"/> class.
        /// </summary>
        /// <param name="configuration">configuration object.</param>
        /// <param name="mongoClient">mongoclient object.</param>
        public BaseRepository(IConfiguration configuration, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(configuration[Database.Name]);
            this.Collection = database.GetCollection<T>(this.DbCollectionName);
            this.DefineIndexes();
        }

        /// <summary>
        /// Gets DB Collection Name.
        /// </summary>
        public abstract string DbCollectionName { get; }

        /// <summary>
        /// MongoDB Collection Name.
        /// </summary>
        protected IMongoCollection<T> Collection { get; }

        public virtual IQueryable<T> Query()
        {
            return this.Collection.AsQueryable();
        }


        /// <summary>
        /// Define Default Indexes for Collection.
        /// </summary>
        protected virtual void DefineIndexes()
        {

        }
    }
}
