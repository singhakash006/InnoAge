﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using MongoDB.Driver;
using static InnoageAdminPortalAPI.Constants.Constants;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Repository
{
    public class TeamRepository:BaseRepository<Team>, ITeamRepository
    {
        public const string CollectionName = Collections.Teams;
        private readonly ILogger _logger;


        public TeamRepository(IConfiguration configuration, IMongoClient mongoClient, ILogHelper logHelper)
       : base(configuration, mongoClient)
        {
            _logger = logHelper.GetLogger<TeamRepository>();
        }

        public override string DbCollectionName => CollectionName;

        public async Task<List<Team>> GetAllAsync(LoggingProperties loggingProperties)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching all teams from the database.");

            try
            {
                var teams = await Collection.Find(_ => true).ToListAsync();

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Successfully fetched {TeamCount} teams.", teams.Count);

                return teams;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching teams.");
                throw;
            }
        }


        public async Task<Team?> GetByIdAsync(LoggingProperties loggingProperties, string id)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching team with ID: {TeamId}", id);

            try
            {
                var team = await Collection.Find(team => team.Id == id).FirstOrDefaultAsync();

                if (team != null)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Successfully fetched team: {TeamName}", team.TeamName);
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No team found with ID: {TeamId}", id);
                }

                return team;
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching team with ID: {TeamId}", id);
                throw;
            }
        }


        public async Task<string?> GetTeamLeaderIdByTeamIdAsync(LoggingProperties loggingProperties, string id)
        {
            _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                .Information("Fetching Team Leader ID for Team ID: {TeamId}", id);

            try
            {
                var team = await Collection.Find(team => team.Id == id).FirstOrDefaultAsync();

                if (team != null && !string.IsNullOrEmpty(team.TeamLeader))
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Information("Found Team Leader ID: {TeamLeaderId} for Team ID: {TeamId}", team.TeamLeader, id);

                    return team.TeamLeader;
                }
                else
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("No Team Leader found for Team ID: {TeamId}", id);

                    return null; // Return null if no Team Leader is found
                }
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, "Error occurred while fetching Team Leader ID for Team ID: {TeamId}", id);
                throw;
            }
        }



       
    }
}
