using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;

namespace InnoageAdminPortalAPI.Repository
{
    public interface ISocialActivityRepository
    {
        
         Task AddActivityAsync(ActivityCalendar activity,LoggingProperties loggingProperties);
         Task<PaginatedResponse<ActivityCalendar>> GetActivitiesByCategoryAsync(LoggingProperties loggingProperties, string category, int pageNumber, int pageSize);
       

    }
}