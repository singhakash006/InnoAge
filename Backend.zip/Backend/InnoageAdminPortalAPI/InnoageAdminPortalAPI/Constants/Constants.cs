﻿namespace InnoageAdminPortalAPI.Constants
{
    public class Constants
    {
        public static class Conventions
        {
            public const string CamelCase = "camelCase";
        }

        public static class Database
        {
            public const string Uri = "Database:Uri";

            public const string Name = "Database:DatabaseName";
        }
        public static class JWT
        {
            public const string Audience = "JWT:ValidAudience";
            public const string Issuer = "JWT:ValidIssuer";
            public const string Secret = "JWT:Secret";
            public const string RefreshTokenTTL = "JWT:RefreshTokenTTL";

        }

        public static class Collections
        {

            public const string RefreshToken = "refresh-token";
            public const string Cart = "Cart";
            public const string Comments = "Comments";
            public const string Department = "Department";
            public const string User = "User";
            public const string Likes = "likes";
            public const string Nominations = "Nominations";
            public const string Dashboard = "Dashboard";
            public const string Teams = "Teams";
            public const string ActivityCalendar = "Activity_Calendar";
            public const string Role = "Role";
            public const string PasswordReset = "PasswordResetToken";



        }

        public static class Hashing
        {
            public const string Key = "Hashing:Key";
        }

        public static class AppMessages
        {
            public const string UserExists = "User Already Exists. Please Try logging into your Account";

            public const string VendorExists = "Vendor Already Exists in your account";

            public const string UnderVerification = "Your Account is under Verification and will be Activated Soon. Please Try After 12-24 Hours!";

            public const string InvalidUser = "Couldn’t find an Active account associated with this Email. Please Try Again!";

            public const string TokenInvalidOrExpired = "Token is Invalid or Already Expired";

            public const string UnableToGenerateToken = "Unable to Generate Token";

            public const string ShopNameAlreadyExist = "Shop Name Already Exists Please Choose Other Shop Name ";

            public const string AccountLocked = "Your account has been locked. please contact your administrator";

            public const string AccountDeactivated = "Your account has been deactivated. please contact your administrator";

            public const string PasswordResetRequired = "Password Reset Required: It seems this is your first login. Please reset your password to continue.";

            public const string InvalidCredentials = "The provided credentials do not match. Please double-check and try again.";

            public const string CreateCustomerShippingAddressSuccess = "Shipping Address created";

            public const string CustomerExist = "Customer Already Exist";

            public const string NotSent = "Email Not Sent";

            public const string EmailSent = "Email Sent Successfully";

            public const string UpdateFail = "Unable To Update Account";

           
        }
    }
}
