﻿namespace InnoageAdminPortalAPI.Constants
{
    public static class LogMessages
    {
        public const string ErrorOccured = "Error Occured in method: {@MethodName}, Error: {@Error}";

        public const string GetRequestReceived = "Get Request Received at Url: {@RequestUri}";

        public const string RequestReceived = "Request Received at Url: {@RequestUri}. Body: {@Body}";

        public const string ResponseSent = "Response Sent with status: {@StatusCode} , Body: {@Body}";

        public const string ServiceResponseSent = "Response Sent from Service: {@Service} with Data:{@ServiceData}";

        public const string MethodStart = "Method: {@MethodName} Execution started";

        public const string MethodEnd = "Method: {@MethodName} Execution Ended. Time Taken: {@TimeTaken}";

        public const string AddSuccess = "Successfully Inserted with Id: {@Id} into Collection: {@CollectionName}";

        public const string DeleteSuccess = "Successfully Deleted Id: {@Id} from Collection: {@CollectionName}";

        public const string UpdateSuccess = "Successfully Updated Id: {@Id} from Collection: {@CollectionName}";

        public const string AddFailure = "Failed to Insert Product:{@Body}";

        public const string TranRolledBack = "Transaction Rolled back due to Error:{@Error}";

        public const string ErrorResponse = "We are unable to Process this request. Please Contact Support Team and Share the error Id:{0}. Date Time Stamp: {1}";

        public const string UpdateSuccesful = "{0} Document updated successfully";

        public const string UpdateFailed = "{0} Document update failed";

        public const string EMailVerified = "User's Email Id Successfully Verified";

        public const string EMailError = "Error occured while sending {@EmailType} to user {@UserId}.";

        public const string OtpVerified = "User Id:{@UserId} OTP Successfully Verified";

        public const string InvalidOtp = "The Provided OTP doesn't match. Please recheck & try again";

        public const string InvalidSubscription = "User Subscription Expired or Invalid ApplicationCode: {@ApplicationCode}";

        public const string RequestSent = "Request Sent to {@Service} with {@RequestJSON}";

        public const string ResponseReceived = "Response Received From {@Service} with Status:{@Status}, Response:{@ResponseJSON}";

        public const string InvalidCredentials = "The Provided Credentials doesn't match. Please recheck & try again";

        public const string ResponseFetched = "Successfully Fetched from Collection: {@CollectionName}, Data :{@Data}";

        public const string RepositoryRequestSent = "Request Sent to Repository: {@Repository} with RequestData: {@RequestJSON}";

        public const string RepositoryResponseReceived = "Response Received From Repository: {@Repository} with Status:{@Status} and Response:{@ResponseJSON}";

        public const string UserAccountLockedUnlocked = "User Account Id:{@UserId} Locked:{@Locked} after Multiple Failed Attempts";

        public const string PasswordUpdatedSuccessfully = "Password Reset Done for User Account Id:{@UserId}";

        public const string UserExists = "User With Email:{@Email} Already exists with Account Id:{@UserId}";

        public const string UserCreated = "New User With Email:{@Email} Created with Account Id:{@UserId}";

        public const string EmailSent = "Email Sent to EmailId:{@TOEmail}, with CC : {@CCEmail} with template Id: {@Template}";

        public const string EmailFailed = "Failed to Send Email: {@Email} due to Error: {@Error}";

        public const string DataFetchFailed = "Failed To Get Data From collection ";

  
    }
}
