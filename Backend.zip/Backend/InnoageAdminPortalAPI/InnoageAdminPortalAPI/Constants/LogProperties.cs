﻿namespace InnoageAdminPortalAPI.Constants
{
    public class LogProperties
    {
        public const string CorrelationId = "CorrelationId";

        public const string UserId = "UserId";

        public const string IsEmailResend = "IsEmailResend";

    }
}
