﻿namespace InnoageAdminPortalAPI.Authorization
{
    namespace MobileAppApi.Authorization
    {
        using InnoageAdminPortalAPI.Enums;
        using InnoageAdminPortalAPI.Models;
        using Microsoft.AspNetCore.Mvc;
        using Microsoft.AspNetCore.Mvc.Filters;
        using System.Diagnostics.CodeAnalysis;


        [ExcludeFromCodeCoverage]
        [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
        public class AuthorizeAttribute : Attribute, IAuthorizationFilter
        {
            private readonly IList<Roles> _roles;

            public AuthorizeAttribute(params Roles[] roles)
            {
                _roles = roles ?? new Roles[] { };
            }

            public void OnAuthorization(AuthorizationFilterContext context)
            {
                // skip authorization if action is decorated with [AllowAnonymous] attribute
                var allowAnonymous = context.ActionDescriptor.EndpointMetadata.OfType<AllowAnonymousAttribute>().Any();
                if (allowAnonymous)
                    return;

                // authorization
                var user = (AuthUserDto)context.HttpContext.Items["User"];
                if (user == null || (_roles.Any() && !Checkroles(_roles, user.Role)))
                {
                    // not logged in or role not authorized
                    context.Result = new JsonResult(new { message = "Unauthorized" }) { StatusCode = StatusCodes.Status401Unauthorized };
                }
            }
            private bool Checkroles(IList<Roles> apiRoles, Roles userRoles)
            {
                var role = apiRoles[0].ToString();
                var apiRoleNumber = Convert.ToInt32((Enum.Parse<Roles>(role)));
                var userRoleNumber = Convert.ToInt32((Enum.Parse<Roles>(userRoles.ToString())));
                if (userRoleNumber >= apiRoleNumber)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}
