﻿using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;

namespace InnoageAdminPortalAPI.Authorization
{
    public interface IJwtUtils
    {
        public TokenDto GenerateJwtToken(UserDetailResponseDto account);

        public AuthUserDto? ValidateJwtToken(string token);

        public RefreshToken GenerateRefreshToken();
    }
}
