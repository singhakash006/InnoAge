﻿using CloudinaryDotNet.Actions;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Enums;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Repository;
using Microsoft.IdentityModel.Tokens;
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace InnoageAdminPortalAPI.Authorization
{
    [ExcludeFromCodeCoverage]
    public class JwtUtils : IJwtUtils
    {
        private readonly IConfiguration configuration;

        private readonly IRefreshTokenRepository _refreshTokenRepository;

        public JwtUtils(
            IConfiguration configuration,
            IRefreshTokenRepository refreshTokenRepository)
        {
            this.configuration = configuration;
            _refreshTokenRepository = refreshTokenRepository;
        }

        public TokenDto GenerateJwtToken(UserDetailResponseDto user)
        {
            // generate token that is valid for 15 minutes
            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(this.configuration[Constants.Constants.JWT.Secret]));


            var authClaims = default(List<Claim>);

            authClaims = new List<Claim>
                                    {
                                        new Claim("userId",user?.Id),
                                        //new Claim("role", user?.UserRole.ToString())
                                        new Claim(ClaimTypes.Role, user?.UserRole.ToString()),
                                        //new Claim("version", appVersion)
                                    };


            var tokenHandler = new JwtSecurityToken(
                issuer: this.configuration[Constants.Constants.JWT.Issuer],
                audience: this.configuration[Constants.Constants.JWT.Audience],
                expires: DateTime.UtcNow.AddDays(180),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256Signature));

            var token = new TokenDto
            {
                Token = new JwtSecurityTokenHandler().WriteToken(tokenHandler),
                ValidTo = tokenHandler.ValidTo
            };
            return token;
        }

        public AuthUserDto? ValidateJwtToken(string token)
        {
            if (token == null)
                return null;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(this.configuration[Constants.Constants.JWT.Secret]);
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var authUser = new AuthUserDto();
                authUser.UserId = (jwtToken.Claims.First(x => x.Type == "userId").Value);
                //authUser.CompanyId = authUser.isSystem ? string.Empty : (jwtToken.Claims.First(x => x.Type == "companyId").Value);
                Roles role;
                if (Enum.TryParse<Roles>(jwtToken.Claims.First(x => x.Type == "role").Value, out role))
                {
                    authUser.Role = role;
                }
                else
                {
                    authUser.Role = Roles.Employee;
                }



                // return account id from JWT token if validation successful
                return authUser;
            }
            catch
            {
                // return null if validation fails
                return null;
            }
        }

        public RefreshToken GenerateRefreshToken()
        {
            var refreshToken = new RefreshToken
            {
                // token is a cryptographically strong random sequence of values
                Token = Convert.ToHexString(RandomNumberGenerator.GetBytes(64)),
                // token is valid for 7 days
                Expires = DateTime.UtcNow.AddDays(180),
                Created = DateTime.UtcNow,
            };

            // ensure token is unique by checking against db
            var tokenIsUnique = _refreshTokenRepository.IsTokenUniqueAsync(refreshToken.Token);

            if (!tokenIsUnique)
                return GenerateRefreshToken();

            return refreshToken;
        }
    }
}
