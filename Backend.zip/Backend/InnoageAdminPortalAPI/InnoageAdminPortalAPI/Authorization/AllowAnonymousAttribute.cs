﻿using System.Diagnostics.CodeAnalysis;

namespace InnoageAdminPortalAPI.Authorization
{
    [ExcludeFromCodeCoverage]
    [AttributeUsage(AttributeTargets.Method)]
    public class AllowAnonymousAttribute : Attribute
    { }
}
