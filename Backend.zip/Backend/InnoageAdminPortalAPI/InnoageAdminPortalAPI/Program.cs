﻿using Serilog;
using Microsoft.OpenApi.Models;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Driver;
using Serilog.Enrichers.Sensitive;
using Serilog.Exceptions;
using static InnoageAdminPortalAPI.Constants.Constants;
using InnoageAdminPortalAPI.Repository;
using InnoageAdminPortalAPI.Services;
using InnoageAdminPortalAPI.Authorization;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Encryption;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using InnoageAdminPortalAPI.AutoMapper;
using InnoageAdminPortalAPI.Controllers;




var builder = WebApplication.CreateBuilder(args);

ConfigurationManager configuration = builder.Configuration;

var services = builder.Services;
builder.Services.AddControllers()
    .AddNewtonsoftJson();

// Add services to the container.
#region Logger Setup
Log.Logger = new LoggerConfiguration()
.Enrich.FromLogContext()
.MinimumLevel.Debug()
.Enrich.WithMachineName()
.Enrich.WithEnvironmentName()
.Enrich.WithExceptionDetails()
.Enrich.WithClientIp()
.Enrich.WithSensitiveDataMasking(options =>
{
    // TODO: ADD firld names to be excluded from Logging
    options.MaskProperties.Add("email");
    options.MaskProperties.Add("username");
    options.MaskProperties.Add("password");
    options.MaskProperties.Add("phonenumber");
}).WriteTo.File("Logs/app_log.txt", rollingInterval: RollingInterval.Day).CreateLogger();
#endregion

services.AddSingleton<IMongoClient, MongoClient>(s =>
{
    var conventionPack = new ConventionPack { new CamelCaseElementNameConvention() };
    ConventionRegistry.Register(
    "Ignore null values",
    new ConventionPack
    {
                new IgnoreIfDefaultConvention(true)
    },
    t => true);
    ConventionRegistry.Register(Conventions.CamelCase, conventionPack, t => true);
    return new MongoClient(configuration[Database.Uri]);
});


// Load MongoDB settings






builder.Services.AddAutoMapper(cfg => cfg.AddProfile<AutoMapperProfile>());
// Register services and repositories
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<ITeamRepository, TeamRepository>();
builder.Services.AddScoped<IDepartmentRepository, DepartmentRepository>();
builder.Services.AddScoped<IPasswordResetRepository, PasswordResetRepository>();
builder.Services.AddScoped<INominationRepository, NominationRepository>();
builder.Services.AddScoped<IRoleRepository ,RoleRepository>();
builder.Services.AddScoped<INominateShoutOutService, NominateShoutOutService>();
builder.Services.AddScoped<IDepartmentService, DepartmentService>();
builder.Services.AddScoped<IEmailService, EmailService>();
builder.Services.AddScoped<ICartService, CartService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<ITeamService, TeamService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ICommentRepository, CommentRepository>();
builder.Services.AddScoped<ILikeRepository, LikeRepository>();
builder.Services.AddScoped<IPostRepository, PostRepository>();
builder.Services.AddScoped<IPostService, PostService>();
builder.Services.AddScoped<ICommentService, CommentService>();
builder.Services.AddScoped<ILikeService, LikeService>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddHostedService<QuarterlyXPResetService>();
builder.Services.AddScoped<ICloudinaryService, CloudinaryService>();
services.AddScoped<IJwtUtils, JwtUtils>();
services.AddScoped<ILogHelper, Logger>();
builder.Services.AddScoped<ICartRepository,CartRepository>();
services.AddScoped<IEncryption, Encryption>();
services.AddScoped<IRefreshTokenRepository, RefreshTokenRepository>();
services.AddScoped< ISocialActivityRepository,SocialActivityRepository>();
services.AddScoped<ISocialActivityService,SocialActivityService>();



////jwt
var jwtSettings = builder.Configuration.GetSection("JWT");
var secretKey = jwtSettings["Secret"];

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtSettings["ValidIssuer"],
            ValidAudience = jwtSettings["ValidAudience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey))
        };
    });



services.AddCors();
services.AddControllers();
services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

services.AddSwaggerGen(swagger =>
{
    //This is to generate the Default UI of Swagger Documentation
    swagger.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "InnoageAdminPortal-API",
        Description = "Innoage Admin Portal API"
    });
    // To Enable authorization using Swagger (JWT)
    swagger.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
    });
    swagger.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
                    {
                          new OpenApiSecurityScheme
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] {}
                    }
        });

}).AddSwaggerGen();
services.AddMemoryCache();

var app = builder.Build();




if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
// global cors policy
app.UseCors(x => x
    .SetIsOriginAllowed(origin => true)
    .AllowAnyMethod()
    .AllowAnyHeader()
    .AllowCredentials());

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.Run();
