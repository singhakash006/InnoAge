﻿namespace InnoageAdminPortalAPI.Models
{
    public class NominationDetailDTO
    {
        public string? UserId { get; set; }
        public string? TeamId { get; set; }
        public string? Reason { get; set; }
        public string? Nomination_Type { get; set; }
        public string[]? ManagerIds { get; set; }
    }
}
