﻿using InnoageAdminPortalAPI.Entity;
using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models
{
    public class PostDto
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]

        public string? Id { get; set; }

        public string type { get; set; }

        public IFormFile? image { get; set; }
        public string? title { get; set; }
        public string? description { get; set; }

        public int totalVotes { get; set; } = 0;

        public List<PollVotes> totalYes { get; set; } = new List<PollVotes>();
        public List<PollVotes> totalNo { get; set; } = new List<PollVotes>();

        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("User")]
        public string? userId { get; set; }


        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime created_at { get; set; }


    }
}
