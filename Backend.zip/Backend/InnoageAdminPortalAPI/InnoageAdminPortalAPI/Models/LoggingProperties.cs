﻿namespace InnoageAdminPortalAPI.Models
{
    public class LoggingProperties
    {
        public Guid CorrelationId { get; set; }

        public string UserId { get; set; }

        public string OrderNumber { get; set; }

        public string EndPoint { get; set; }
    }
}
