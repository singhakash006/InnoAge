﻿namespace InnoageAdminPortalAPI.Models
{
    public class DashboardDto
    {
        public NominationGetDto? NominationData { get; set; }
        public PostGetDto? PostData { get; set; }

        public UserDetailed? UserData { get; set; }
    }

    public class UserDetailed
    {
        public string UserName { get; set; }
        public string ProfileImage { get; set; }
    }
}
