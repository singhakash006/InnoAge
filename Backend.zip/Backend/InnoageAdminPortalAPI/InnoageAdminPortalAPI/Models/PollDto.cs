﻿using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models
{
    public class PollDto
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("Posts")]
        public string postId { get; set; }

        public string voteType { get; set; }

        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("User")]

        public string userId { get; set; }
    }
}
