﻿using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models
{
    public class LikeDto
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("Posts")]
        public string postId { get; set; }

        public string? userId { get; set; }
    }
}
