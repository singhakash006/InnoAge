﻿namespace InnoageAdminPortalAPI.Models
{
    public class EmailDTO
    {
        public string Email { get; set; }
    }
}
