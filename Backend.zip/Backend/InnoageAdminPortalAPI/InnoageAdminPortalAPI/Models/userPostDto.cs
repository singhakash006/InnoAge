﻿using InnoageAdminPortalAPI.Entity;
using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models
{
    public class userPostDto
    {
        public string Id { get; set; }
        public string type { get; set; }
        public string image { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public int totalVotes { get; set; } = 0;
        public List<PollVotes> totalYes { get; set; } = new List<PollVotes>();
        public List<PollVotes> totalNo { get; set; } = new List<PollVotes>();
        public string UserId { get; set; }
        public User User { get; set; }
        public DateTime? created_at { get; set; }
        public List<Like> Like { get; set; } = new List<Like>();
        public List<Comment> Comment { get; set; } = new List<Comment>();
    }
}
