﻿using InnoageAdminPortalAPI.Entity;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models
{
    public class NominationGetDto:Nomination
    {
        
        public List<Comment> postComments { get; set; }
        public List<Like> postLikes { get; set; }
    }
}
