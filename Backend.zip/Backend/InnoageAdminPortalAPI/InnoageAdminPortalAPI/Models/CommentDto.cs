﻿

namespace InnoageAdminPortalAPI.Models
{
    public class CommentDto
    {
        public string postId { get; set; }
        public string commentMessage { get; set; }
        public string userName { get; set; }

    }
}
