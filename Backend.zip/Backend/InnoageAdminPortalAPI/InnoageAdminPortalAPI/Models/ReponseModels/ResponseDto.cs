﻿namespace InnoageAdminPortalAPI.Models.ReponseModels
{
    public class ResponseDto
    {
        public int StatusCode { get; set; }
        public object Message { get; set; }
        public bool IsError { get; set; }

        public object Data {get;set;}
    }
}
