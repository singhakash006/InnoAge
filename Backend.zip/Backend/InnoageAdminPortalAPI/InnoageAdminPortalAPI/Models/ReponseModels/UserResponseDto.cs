﻿using System.Text.Json.Serialization;

namespace InnoageAdminPortalAPI.Models.ReponseModels
{
    public class UserResponseDto
    {
        public UserDetailResponseDto User { get; set; }

        public string Token { get; set; }

        public DateTime TokenExpiration { get; set; }

        [JsonIgnore] // refresh token is returned in http only cookie
        public string RefreshToken { get; set; }
    }
}
