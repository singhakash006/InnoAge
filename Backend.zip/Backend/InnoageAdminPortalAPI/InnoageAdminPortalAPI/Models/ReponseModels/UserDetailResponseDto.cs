﻿using InnoageAdminPortalAPI.Enums;
using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models.ReponseModels
{
    public class UserDetailResponseDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public string Address { get; set; }
        public string EmployeeId { get; set; }
        public string Designation { get; set; }
        public string Department { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string Image { get; set; }
        public string TeamLeaderId { get; set; }
        public string TeamLeaderName { get; set; }
        public string TeamLeaderEmail { get; set; }
        public Roles UserRole { get; set; }
    }
}
