﻿namespace InnoageAdminPortalAPI.Models
{
    public class UserIdDTO
    {
        public string UserId { get; set; }
    }
}
