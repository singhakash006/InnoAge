﻿using InnoageAdminPortalAPI.Enums;

namespace InnoageAdminPortalAPI.Models
{
    public class AuthUserDto
    {
        public string UserId { get; set; }

        public Roles Role { get; set; }
    }
}
