﻿namespace InnoageAdminPortalAPI.Models
{
    public class TokenDto
    {
        public string Token { get; set; }

        public DateTime ValidTo { get; set; }
    }
}
