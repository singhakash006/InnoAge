using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System.Text.Json.Serialization;
using InnoageAdminPortalAPI.Enums;

namespace InnoageAdminPortalAPI.Models
{
    public class AddActivityDto
    {
         [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("activity_name")]
        public string ActivityName { get; set; }

        [BsonElement("description")]
        public string Description { get; set; }

        [BsonElement("date")]
        public DateTime Date { get; set; }

        [BsonElement("timing")]
        public string Timing { get; set; }

        [BsonElement("organisers")]
        public List<string> Organisers { get; set; }

        [BsonElement("Category")]
        [BsonRepresentation(BsonType.String)]
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public ActivityCategory Category { get; set; }
    }

    

}