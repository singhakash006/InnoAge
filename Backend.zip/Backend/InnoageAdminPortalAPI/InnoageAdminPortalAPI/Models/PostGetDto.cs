﻿using InnoageAdminPortalAPI.Entity;
using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Models
{
    public class PostGetDto:Posts
    {
      
        public List<Comment> postComments { get; set; }
        public List<Like> postLikes { get; set; }


    }
}
