﻿using AutoMapper;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using System.Diagnostics.CodeAnalysis;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;

namespace InnoageAdminPortalAPI.AutoMapper
{
    [ExcludeFromCodeCoverage]
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
                CreateMap<PostDto, Posts>()
               .ForMember(dest => dest.image, opt => opt.Ignore());

            CreateMap<CommentDto, Comment>();
            CreateMap<LikeDto, Like>();
            // CreateMap<CustomerModel, CustomerEntity>().ReverseMap();

           // CreateMap<CustomerModel, CustomerEntity>().ReverseMap();
           CreateMap<AddActivityDto, ActivityCalendar>();
            CreateMap<ActivityCalendar,AddActivityDto>();

        }
    }
}
