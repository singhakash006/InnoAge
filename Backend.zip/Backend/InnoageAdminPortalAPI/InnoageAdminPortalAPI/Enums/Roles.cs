﻿namespace InnoageAdminPortalAPI.Enums
{
    public enum Roles
    {
        Admin=1,
        HR=2,
        TeamLeader=3,
        Employee=4
    }
}
