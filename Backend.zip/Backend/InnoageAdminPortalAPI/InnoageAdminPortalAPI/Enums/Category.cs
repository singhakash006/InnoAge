namespace InnoageAdminPortalAPI.Enums
{
    public enum ActivityCategory
    {
        
        SportsEvent,
        CompanyEvents,
        TeamLunchAndOutings,
        Social
    }
}