﻿namespace InnoageAdminPortalAPI.Helpers
{
    using Serilog;
    public interface ILogHelper
    {
        ILogger GetLogger<T>();
    }
}
