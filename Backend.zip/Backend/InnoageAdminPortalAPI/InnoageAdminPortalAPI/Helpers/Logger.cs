﻿using Serilog;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Helpers
{
    public class Logger:ILogHelper
    {
        public ILogger GetLogger<T>()
        {
            return Log.ForContext<T>();
        }
    }
}
