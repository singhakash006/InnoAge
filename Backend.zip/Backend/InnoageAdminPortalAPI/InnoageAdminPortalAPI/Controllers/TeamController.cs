﻿using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Threading.Tasks;

namespace InnoageAdminPortalAPI.Controllers
{
    [Route("teams")]
    [Authorize]
    [ApiController]
    public class TeamController : ControllerBase
    {
        private readonly ITeamService _teamService;
        private readonly Serilog.ILogger _logger;

        public TeamController(ITeamService teamService, ILogHelper loghelper)
        {
            _teamService = teamService;
            _logger = loghelper.GetLogger<TeamController>();
        }

        [HttpGet("fetch_all_teams")]
        public async Task<IActionResult> FetchAllTeams()
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.FetchAllTeams));

                var response = await _teamService.GetAllTeamsWithLeaderDetailsAsync(loggingProperties);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.Teams, response);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.FetchAllTeams), ex.Message);

                return StatusCode(500, new { message = "An error occurred while fetching teams.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.FetchAllTeams), watch.Elapsed.TotalSeconds);
            }
        }

    }
}
