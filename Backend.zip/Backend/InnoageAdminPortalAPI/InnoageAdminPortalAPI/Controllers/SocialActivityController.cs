using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Helpers;
using System.Diagnostics;
using InnoageAdminPortalAPI.Constants;
using System.Net;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Services;
using Microsoft.AspNetCore.Mvc;


namespace InnoageAdminPortalAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SocialActivityController : ControllerBase
    {
        private readonly ISocialActivityService _socialActivityService;
        private readonly Serilog.ILogger _logger;

        public SocialActivityController(ISocialActivityService socialActivityService, ILogHelper loghelper)
        {
            _logger = loghelper.GetLogger<SocialActivityController>();
            _socialActivityService = socialActivityService;
        }
        [HttpPost]
        public async Task<IActionResult> AddActivity([FromBody] AddActivityDto activity)
        {
            var watch = Stopwatch.StartNew();

            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid()
            };
            var response = new ResponseDto();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(AddActivity));

                response.Message = await _socialActivityService.AddActivityAsync(loggingProperties, activity);
                response.StatusCode = (int)HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.IsError = true;
                response.Message = "An error occurred while processing your request.";

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorResponse, nameof(this.AddActivity), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(this.AddActivity), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);
        }
        [HttpGet("category/{category}/page/{pageNumber}")]
        public async Task<IActionResult> GetActivitiesByCategory(string category, int pageNumber, int pageSize = 10)
        {
            var watch = Stopwatch.StartNew();

            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid()
            };
            var response = new ResponseDto();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodStart, nameof(GetActivitiesByCategory));

                var paginatedResult = await _socialActivityService.GetActivitiesByCategoryAsync(loggingProperties, category, pageNumber, pageSize);

                response.Message = "Activities fetched successfully";
                response.StatusCode = (int)HttpStatusCode.OK;
                response.Data = paginatedResult;
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.IsError = true;
                response.Message = "An error occurred while processing your request.";

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorResponse, nameof(GetActivitiesByCategory), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(GetActivitiesByCategory), watch.Elapsed.TotalSeconds);
            }

            return StatusCode(response.StatusCode, response);
        }



    }
}