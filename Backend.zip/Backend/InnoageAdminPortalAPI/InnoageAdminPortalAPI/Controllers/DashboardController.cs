﻿
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Models.ReponseModels;
using InnoageAdminPortalAPI.Repository;
using InnoageAdminPortalAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net;



namespace InnoageAdminPortalAPI.Controllers
{
    
    [ApiController]
    [Authorize]
    [Route("/api[controller]")]

    public class DashboardController : Controller
    {
        private readonly IPostService _postService;
        private readonly ILikeService _likeService;
        private readonly ICommentService _commentService;
        private readonly Serilog.ILogger _logger;
        public DashboardController(IPostService postService, ILikeService likeService, ICommentService commentService, ILogHelper loghelper)
        {
            _postService = postService;
            _likeService = likeService;
            _commentService = commentService;
            _logger=loghelper.GetLogger<DashboardController>();
           
        }

       
        [HttpGet]
        [Route("GetAllPostFromServices")]
        public async Task<IActionResult> GetAllPostFromServices(DateTime? lastFetchedDate, int limit = 10)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                response.Message = await _postService.GetAllLatestPostService(loggingProperties, lastFetchedDate, limit);
                response.StatusCode = (int)HttpStatusCode.OK;
               
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = ex.Message;
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorResponse, nameof(this.GetAllPostFromServices), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(this.GetAllPostFromServices), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);
        }

        //Insert post in database
        [HttpPost]
        [Route("InsertPost")]
        public async Task<IActionResult> InsertPost([FromForm] PostDto post)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                post.Id = null;
                response.Message = await _postService.InsertPostService(loggingProperties, post);
                response.StatusCode = (int)HttpStatusCode.OK;
              
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = ex.Message;

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorResponse, nameof(this.InsertPost), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.InsertPost), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);
        }

        [HttpPost]
        [Route("InsertLike")]
        public async Task<IActionResult> InsertLike([FromBody] LikeDto like)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                response.Message = await _likeService.InsertLike(loggingProperties, like);
  
                    response.StatusCode = (int)HttpStatusCode.OK;
                
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;    
                response.Message = ex.Message;
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, LogMessages.ErrorResponse, nameof(this.InsertLike), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                  .Debug(LogMessages.MethodEnd, nameof(this.InsertLike), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);
        }


        [HttpPost]
        [Route("commentAdd")]
        public async Task<IActionResult> InsertComment([FromBody] CommentDto comment)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                response.Message= await _commentService.InsertCommentService(loggingProperties, comment);
                response.StatusCode = (int)HttpStatusCode.OK;


            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = ex.Message;
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, LogMessages.ErrorResponse, nameof(this.InsertComment), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                  .Debug(LogMessages.MethodEnd, nameof(this.InsertComment), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);


        }
        [HttpPatch]
        [Route("Updatepoll")]
        public async Task<IActionResult> UpdatePoll([FromBody] PollDto poll)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                response.Message = await _postService.UpdatePollPostService(loggingProperties, poll);
               
                    response.StatusCode = (int)HttpStatusCode.OK;
               
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = ex.Message;
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, LogMessages.ErrorResponse, nameof(this.UpdatePoll), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                  .Debug(LogMessages.MethodEnd, nameof(this.UpdatePoll), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);
        }



    }
}
