﻿using System.Diagnostics;
using System.Security.Claims;
using InnoageAdminPortalAPI.Constants;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ILogger = Serilog.ILogger;

namespace InnoageAdminPortalAPI.Controllers
{
    [ApiController]
    [Authorize] 
    public class NominateShoutOutController : ControllerBase
    {
        INominateShoutOutService _nominationService;
        private readonly Serilog.ILogger _logger;
        public NominateShoutOutController(INominateShoutOutService nominationService, ILogHelper loghelper)
        {
            _nominationService = nominationService;
            _logger = loghelper.GetLogger<NominateShoutOutController>();
        }

        [Authorize]
        [HttpPost("/api/shoutout")]
        public async Task<IActionResult> NominateEmployee([FromBody] NominationDetailDTO model)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.NominateEmployee));

                var response = await _nominationService.NominateShoutEmployee(
                    loggingProperties,
                    model.UserId,
                    model.TeamId,
                    model.Reason,
                    model.Nomination_Type,
                    model.ManagerIds
                );

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Nomination request processed successfully for UserId: {UserId}", model.UserId);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.NominateEmployee), ex.Message);

                return StatusCode(500, new { message = "An error occurred while nominating the employee.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.NominateEmployee), watch.Elapsed.TotalSeconds);
            }
        }

        [Authorize(Roles = "HR")]
        [HttpGet("/users/fetch_nominated_employees")]
        public async Task<IActionResult> Fetch_Nominated_Employees_By_TeamLeaders()
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.Fetch_Nominated_Employees_By_TeamLeaders));

                var response = await _nominationService.GetNominationsByTeamLeaders(loggingProperties);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.Nominations, response);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.Fetch_Nominated_Employees_By_TeamLeaders), ex.Message);

                return StatusCode(500, new { message = "An error occurred while fetching nominations.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.Fetch_Nominated_Employees_By_TeamLeaders), watch.Elapsed.TotalSeconds);
            }
        }



        
    }
}