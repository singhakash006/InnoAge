﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using InnoageAdminPortalAPI.Services;
using System;
using System.Threading.Tasks;
using InnoageAdminPortalAPI.Entity;
using InnoageAdminPortalAPI.Models;
using Microsoft.IdentityModel.Logging;
using InnoageAdminPortalAPI.Helpers;
using System.Diagnostics;
using InnoageAdminPortalAPI.Constants;
using SendGrid;
using System.Net;
using InnoageAdminPortalAPI.Models.ReponseModels;
using Microsoft.AspNetCore.Authorization;


namespace InnoageAdminPortalAPI.Controllers
{
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly Serilog.ILogger _logger;

        public AuthController(IAuthService authService, ILogHelper loghelper)
        {
            _logger = loghelper.GetLogger<AuthController>();
            _authService = authService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> LoginAsync([FromBody] LoginDto model)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                 response.Message = await _authService.LoginAsync(loggingProperties, model);

                if (response.Message == null)
                {
                    response.StatusCode = (int)HttpStatusCode.OK; ;
                    response.IsError = true;
                    response.Message = LogMessages.InvalidCredentials;
                }
                else
                {                    
                    response.StatusCode = (int)HttpStatusCode.OK;
                }
            }
            catch(Exception ex) {
                if (!string.IsNullOrWhiteSpace(ex.Message) && (ex.Message.ToLower().Contains("please") || ex.Message.ToLower().Contains("suspicious")))
                {
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.IsError = true;
                    response.Message = ex.Message;
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.NotImplemented;
                    response.Message = string.Format(LogMessages.ErrorResponse, loggingProperties.CorrelationId, DateTime.UtcNow);
                }
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                   .Error(ex, LogMessages.ErrorResponse, nameof(this.LoginAsync), ex.Message);
            }
            finally {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                  .Debug(LogMessages.MethodEnd, nameof(this.LoginAsync), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);

        }

        [HttpPost("signup")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> SignupAsync([FromBody] User model)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties() { CorrelationId = Guid.NewGuid() };
            var response = new ResponseDto();

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Information(LogMessages.MethodStart, nameof(this.SignupAsync));

                response.Message = await _authService.SignupAsync(loggingProperties, model); // ✅ Pass loggingProperties
                response.StatusCode = (int)HttpStatusCode.OK;

                if (response.Message is string message && message.Contains("already registered", StringComparison.OrdinalIgnoreCase))
                {
                    response.IsError = true;
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Information(LogMessages.AddSuccess, model.Id, Constants.Constants.Collections.User);
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.IsError = true;
                response.Message = string.Format(LogMessages.ErrorResponse, loggingProperties.CorrelationId, DateTime.UtcNow);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Error(ex, LogMessages.ErrorResponse, nameof(this.SignupAsync), ex.Message);
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                       .Debug(LogMessages.MethodEnd, nameof(this.SignupAsync), watch.Elapsed.TotalSeconds);
            }

            return StatusCode(response.StatusCode, response);
        }



       



        [HttpPost("request-password-reset")]
        public async Task<IActionResult> RequestPasswordReset([FromBody] EmailDTO request)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.RequestPasswordReset));

                string email = request.Email;
                bool success = await _authService.RequestPasswordResetAsync(loggingProperties, email);

                if (!success)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Password reset request failed: Email not found - {Email}", email);
                    return BadRequest(new { message = "Email not found", success = false });
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Password reset email sent to: {Email}", email);

                return Ok(new { message = "Password reset email sent!", success = true });
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.RequestPasswordReset), ex.Message);

                return StatusCode(500, new { message = "An error occurred while processing your request.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.RequestPasswordReset), watch.Elapsed.TotalSeconds);
            }
        }



        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDTO model)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.ResetPassword));

                bool success = await _authService.ResetPasswordAsync(loggingProperties, model.Token, model.NewPassword);

                if (!success)
                {
                    _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                        .Warning("Password reset failed: Invalid or expired token - {Token}", model.Token);
                    return BadRequest(new { message = "Invalid or expired token", success = false });
                }

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information("Password reset successful for token: {Token}", model.Token);

                return Ok(new { message = "Password reset successful!", success = true });
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.ResetPassword), ex.Message);

                return StatusCode(500, new { message = "An error occurred while processing your request.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.ResetPassword), watch.Elapsed.TotalSeconds);
            }
        }


    }


}
