﻿using InnoageAdminPortalAPI.Constants;
using System.Diagnostics;
using InnoageAdminPortalAPI.Helpers;
using InnoageAdminPortalAPI.Models;
using InnoageAdminPortalAPI.Repository;
using InnoageAdminPortalAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using InnoageAdminPortalAPI.Models.ReponseModels;
using Microsoft.AspNetCore.JsonPatch;
using System.Net;
using InnoageAdminPortalAPI.Entity;

namespace InnoageAdminPortalAPI.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserService _userService;
        private readonly Serilog.ILogger _logger;

        public UserController(IUserService userService, ILogHelper loghelper)
        {
            _userService = userService;
            _logger = loghelper.GetLogger<AuthController>();
        }


        [HttpGet("fetch_my_employees")]
        public async Task<IActionResult> FetchMyEmployees()
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.FetchMyEmployees));

                var response = await _userService.GetEmployeeByTeamIdAsync(loggingProperties);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.User, response);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.FetchMyEmployees), ex.Message);

                return StatusCode(500, new { message = "An error occurred while fetching employees.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.FetchMyEmployees), watch.Elapsed.TotalSeconds);
            }
        }


        [HttpGet("fetch_all_TeamLeaders")]
        [Authorize]
        public async Task<IActionResult> fetch_all_TeamLeaders()
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties
            {
                CorrelationId = Guid.NewGuid()
            };

            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.MethodStart, nameof(this.fetch_all_TeamLeaders));

                var response = await _userService.GetTLsAsync(loggingProperties);

                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Information(LogMessages.ResponseFetched, Constants.Constants.Collections.User, response);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(this.fetch_all_TeamLeaders), ex.Message);

                return StatusCode(500, new { message = "An error occurred while fetching team leaders.", success = false });
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(this.fetch_all_TeamLeaders), watch.Elapsed.TotalSeconds);
            }
        }

        [HttpPatch("UpdateUserProfile/{EmpId}")]
        public async Task<IActionResult> UpdateUserProfile(string EmpId, [FromBody] JsonPatchDocument<User> patchDoc)
        {
            var watch = Stopwatch.StartNew();
            var loggingProperties = new LoggingProperties()
            {
                CorrelationId = Guid.NewGuid(),
            };
            var response = new ResponseDto();
            try
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodStart, nameof(UpdateUserProfile));

                if (patchDoc == null)
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.IsError = true;
                    response.Message = "Invalid update request";
                    return BadRequest(response);
                }

                var result = await _userService.UpdateUserAsync(loggingProperties, EmpId, patchDoc);

                if (result == null)
                {
                    response.StatusCode = (int)HttpStatusCode.NotFound;
                    response.IsError = true;
                    response.Message = "User not found";
                    return NotFound(response);
                }

                if (!result.Value)
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.IsError = true;
                    response.Message = "Update failed";
                    return BadRequest(response);
                }

                response.StatusCode = (int)HttpStatusCode.OK;
                response.Message = "User updated successfully";
            }
            catch (Exception ex)
            {
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Error(ex, LogMessages.ErrorOccured, nameof(UpdateUserProfile), ex.Message);
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = "An error occurred while updating the user profile.";
            }
            finally
            {
                watch.Stop();
                _logger.ForContext(LogProperties.CorrelationId, loggingProperties.CorrelationId)
                    .Debug(LogMessages.MethodEnd, nameof(UpdateUserProfile), watch.Elapsed.TotalSeconds);
            }
            return StatusCode(response.StatusCode, response);
        }

    }
}