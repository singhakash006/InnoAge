﻿using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Entity
{
    public class Comment
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public string? Id { get; set; }

        public string userName { get; set; }
        public string commentMessage { get; set; }
        
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("Posts")]
        public string postId { get; set; }
        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime created_at { get; set; } = DateTime.UtcNow;

    }

}
