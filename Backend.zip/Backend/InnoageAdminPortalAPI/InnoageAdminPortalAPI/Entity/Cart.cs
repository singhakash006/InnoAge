﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace InnoageAdminPortalAPI.Entity
{
    public class Cart
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("XPs")]
        public int XPs { get; set; }   // Must be an integer and is required

    }

}
