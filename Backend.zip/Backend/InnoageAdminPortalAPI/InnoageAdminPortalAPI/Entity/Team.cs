﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace InnoageAdminPortalAPI.Entity
{
    public class Team
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("Team")]
        public string TeamName { get; set; }  // Name of the team

        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("TeamLeader")]
        public string TeamLeader { get; set; }

    }
}
