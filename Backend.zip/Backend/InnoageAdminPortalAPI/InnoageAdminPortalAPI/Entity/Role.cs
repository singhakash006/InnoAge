﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using InnoageAdminPortalAPI.Enums;

namespace InnoageAdminPortalAPI.Entity
{
    public class Role
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("Role")]
        public string RoleName { get; set; }  // Name of the role
    }
}
