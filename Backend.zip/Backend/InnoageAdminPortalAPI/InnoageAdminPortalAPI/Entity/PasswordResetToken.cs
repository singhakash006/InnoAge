﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace InnoageAdminPortalAPI.Entity
{
    public class PasswordResetToken
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string Email { get; set; }  // User's email

        public string Token { get; set; }  // Secure token for password reset

        public DateTime ExpiresAt { get; set; }  // Token expiration time
    }
}
