﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace InnoageAdminPortalAPI.Entity
{
    public class Department
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("Department")]
        public string DepartmentName { get; set; }  // Name of the department
    }
}
