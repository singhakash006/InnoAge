﻿using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Entity
{
    public class Like
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]

        public string? Id { get; set; }

        public string userId { get; set; }
      

        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("Posts")]
        public string postId { get; set; }
    }
}
