﻿using MongoDB.Bson.Serialization.Attributes;

namespace InnoageAdminPortalAPI.Entity
{
    public class Posts
    {
        public Posts()
        {
            created_at = DateTime.UtcNow;
        }

        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public string? Id { get; set; }
        [BsonElement("type")]
        public string type { get; set; }
        [BsonElement("image")]
        public string? image { get; set; }
        [BsonElement("title")]
        public string? title { get; set; }
        [BsonElement("description")]
        public string? description { get; set; }
        [BsonElement("totalVotes")]
        public int totalVotes { get; set; } = 0;

        [BsonElement("totalYes")]
        public List<PollVotes> totalYes { get; set; } = new List<PollVotes>();
        [BsonElement("totalNo")]
        public List<PollVotes> totalNo { get; set; } = new List<PollVotes>();

        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("User")]
        public string? userId { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime created_at { get; set; }
    }

    public class PollVotes
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("User")]
        public string userId { get; set; }
    }
}
