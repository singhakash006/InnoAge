﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace InnoageAdminPortalAPI.Entity
{
    public class Nomination
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        
        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("UserId")]
        public string? UserId { get; set; }

        
        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("TeamId")]
        public string? TeamId { get; set; }


        [BsonElement("Nomination_Type")]
        public string Nomination_Type { get; set; }


        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("Nominated_By")]
        public string? Nominated_By { get; set; }

        [BsonElement("Reason")]
        public string Reason { get; set; }

        [BsonIgnoreIfDefault(false)]
        [BsonElement("isApproved")]
        public bool isApproved { get; set; }

        [BsonElement("CreatedAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        
        [BsonElement("VerifiedAt")]
        public DateTime? VerifiedAt { get; set; }
    }
}
