﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace InnoageAdminPortalAPI.Entity
{
    public class Award
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime Date { get; set; }  // Date when the award was given

        public string AwardType { get; set; }  // Type of award received

        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; }  // Reference to the user who received the award
    }
}
