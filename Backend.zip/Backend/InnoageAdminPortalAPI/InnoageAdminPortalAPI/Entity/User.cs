﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace InnoageAdminPortalAPI.Entity
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("_id")]
        public string? Id { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("Team")]
        public string TeamId { get; set; }

        [BsonElement("Name")]
        public string Name { get; set; }

        [BsonElement("EmployeeId")]
        public string EmployeeId { get; set; }

        [BsonElement("Designation")]
        public string Designation { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        [BsonElement("DOB")]
        public DateTime DOB { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("Role")]
        public string RoleId { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        [BsonElement("DOJ")]
        public DateTime DOJ { get; set; }

        [BsonElement("Email")]
        public string Email { get; set; }

        [BsonElement("Password")]
        public string Password { get; set; }

        [BsonElement("Verified")]
        public bool Verified { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("Department")]
        public string DepartmentId { get; set; }

        [BsonElement("Image")]
        public string Image { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("Cart")]
        public string? CartId { get; set; }

        [BsonElement("PhoneNo")]
        public string PhoneNo { get; set; }

        [BsonElement("Address")]
        public string Address { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("TeamLeaderId")]
        public string? TeamLeaderId { get; set; }

        [BsonElement("isLocked")]
        public bool isLocked { get; set; }

        [BsonElement("isActive")]
        public bool isActive { get; set; }
    }
}
